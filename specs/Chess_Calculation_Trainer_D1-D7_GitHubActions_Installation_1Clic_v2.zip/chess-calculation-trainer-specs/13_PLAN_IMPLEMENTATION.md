# 13 — Plan de réalisation priorisé et vérifications de sortie

## Lot 0 — Dépendances et preuve d'intégration (bloquant)

- Pinner versions de `react-chessboard`, `react-arborist`, `chess.js` si retenu, `python-chess`, Stockfish 19, Python/Node.
- Valider licences, compatibilité React/Node et les fonctionnalités échiquier/éditeur ; exécuter *spike* FEN→échiquier + PGN à variantes→arbre contrôlé + move→légalité serveur.
- Construire Stockfish source tag stable dans image `linux/amd64`, NNUE présente, smoke UCI.
- **DoD :** échantillon fonctionnel démontrable sous Linux + rapport des API réelles, pas hypothétiques.

## Lot 1 — Noyau domaine/API et position

- Modèle SQLite/migrations.
- Import FEN/PGN (RAV, métadonnées, erreurs), éditeur, validation, snapshots et navigation.
- API REST et tests domaine.
- **DoD :** depuis un PGN avec variante, on choisit un nœud, visualise sa position et conserve le contexte.

## Lot 2 — Exercices B/C sans moteur apparent

- Modes mental strict et arbre utilisateur.
- Saisie SAN/éditeur, parent/enfant, undo/redo, soumission immuable, révélation différée.
- Tests anti-spoiler au niveau **API**, pas seulement interface.
- **DoD :** calcul et sauvegarde possibles hors ligne avec moteur désactivé ; aucune fuite.

## Lot 3 — Orchestrateur Stockfish progressif

- Un processus UCI, contrôles mémoire/CPU, queue, annulation, progression SSE.
- MultiPV racine jusqu'à 20, paliers 8/12/16/21, budget, profondeur attestée, cache.
- Tableau des meilleurs coups sous échiquier en mode A/révélation.
- **DoD :** état stable sous interruptions, crash et redémarrage ; résultats corrects et tracés.

## Lot 4 — Référence ramifiée et corrections

- Politique d'expansion sous budget, défenses adverses, branches utilisateur à la demande.
- Comparateur de chemins/transpositions prudent, taxonomie de diagnostics.
- Débriefing preuves et incertitudes ; historique.
- **DoD :** corpus de 20 exercices donne des diagnostics attendus et abstention quand référence insuffisante.

## Lot 5 — UX et performance

- shadcn/ui, accessibilité, états vides, validations, clavier, dark/light facultatif.
- Profilage sur positions coûteuses, limites robustes, streaming cohérent, navigation.
- **DoD :** Playwright desktop/mobile, pas de blocage UI sur analyse active.

## Lot 6 — Publication Linux → GitHub → Windows

- Docker image unique, GH Actions CI/release, GHCR public digest, bundle PowerShell.
- Tests Pester et vérification manuelle Windows 11 x64.
- README, licences, sauvegardes et scripts start/stop/update/uninstall.
- **DoD :** machine Windows propre compatible, avec Docker Desktop/WSL, installe depuis Release sans dépendances de développement ; permet restauration de données.

## Discipline pour le LLM

- Faire un lot complet, tests verts et commit Git cohérent, avant suivant.
- Ne pas ajouter de fonctionnalités tant qu'un gate n'est pas satisfait.
- À chaque tâche livrer : fichiers créés/modifiés, choix, commandes et sorties de tests, risques restants.
- Quand l'implémenteur manque d'un outil réel (notamment Windows), le mentionner et conserver une checklist de validation manuelle plutôt que déclarer succès.
- Un test raté = correction du code ou du test erroné, pas suppression du critère d'acceptation.


## Gate additionnelle — GitHub Actions et installation double-clic

Après les lots initiaux, appliquer les documents 18–20 : workflow sur `main`, PR, exécution manuelle et tag release ; GHCR public ; installeur Windows `.cmd` au premier niveau du ZIP de release ; tests G01–G06 et W01–W12. Les modèles fournis dans `templates/` sont des bases techniques à intégrer et tester. Une image construite sous Ubuntu ne dispense pas de tester réellement le parcours Windows + Docker Desktop.
