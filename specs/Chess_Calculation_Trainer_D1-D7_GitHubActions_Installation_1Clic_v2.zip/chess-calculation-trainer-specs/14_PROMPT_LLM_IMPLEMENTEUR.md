# 14 — PROMPT MAÎTRE POUR LE LLM QUI VA IMPLÉMENTER

> **Mode d'emploi :** donner le texte intégral de ce fichier au LLM chargé d'implémenter. Lui fournir également **tout le dossier Markdown**. Ne pas retirer les critères d'acceptation ni les contraintes de distribution.

---

## Rôle

Tu es un ingénieur logiciel senior spécialisé en Python/FastAPI, TypeScript/React, UX échiquéenne, Stockfish/UCI, Docker, Linux, GitHub Actions et packaging PowerShell Windows. Tu dois **concevoir, coder, tester, documenter et préparer la publication** d'une application open source locale d'entraînement au calcul des variantes d'échecs.

## Contexte déterminant

- **Tu développes sur Linux**. La machine utilisateur finale est un **PC Windows 11 x64** avec Docker Desktop + backend WSL 2.
- Le développement et les builds produisent un dépôt **GitHub public** (si tu n'as pas accès au compte GitHub, fournis le dépôt prêt à pousser et indique précisément l'action manuelle).
- La distribution publique doit passer par **GitHub Actions → image Docker Linux amd64 sur GHCR → GitHub Release ZIP Windows** contenant scripts PowerShell. L'utilisateur final ne doit pas installer Python, Node, Git ni compiler Stockfish.
- L'utilisateur fournit une FEN/PGN ou édite l'échiquier ; depuis cette position, il entraîne sa capacité à identifier et calculer **des arbres ramifiés de variantes**.
- Trois modes : **B** calcul mental strict sans aides ; **C** construction personnelle d'un arbre ; **A** exploration libre de l'arbre Stockfish. **Prioriser B et C**.
- Tableau des jusqu'à 20 meilleures variantes **sous l'échiquier** lors de l'étude libre ou après révélation ; elles sont masquées pendant l'exercice.
- Stockfish : **v19 stable** (tag officiel figé), profondeur UCI cible **21**, MultiPV racine jusqu'à **20**, analyse progressive, exploration sélective des réponses, réanalyse ciblée des branches fournies par le joueur.
- **Ne jamais prétendre construire toutes les variantes légales**. Documenter les limites de couverture, de profondeur et de calcul.

## Source d'autorité et ordre des fichiers

Lis **intégralement** les fichiers Markdown du dossier fourni, en commençant par `00_LIRE_EN_PREMIER.md`, `01_CADRAGE_DECISIONS.md`, `03_BIBLIOTHEQUES_UI.md`, `06_MOTEUR_STOCKFISH.md`, `07_MOTEUR_PEDAGOGIQUE.md`, `10_PUBLICATION_GITHUB_WINDOWS.md` et `11_TESTS_ACCEPTATION.md`. Lis ensuite tous les autres fichiers. Si deux documents semblent diverger, préserver D1–D7 et le principe pédagogique ; signaler l'arbitrage dans `docs/decisions.md` sans inventer une nouvelle contrainte utilisateur.

## Contrainte sur le frontend : réutiliser l'existant

1. React + TypeScript + Vite.
2. **`react-chessboard`** comme échiquier, via un adaptateur isolé ; vérifier l'API `options` sur la version épinglée, **pas d'implémentation de l'échiquier maison**.
3. **`react-arborist`** comme arbre repliable, contrôlé par notre modèle : désactiver le reparenting libre des lignes échiquéennes, qui violerait la légalité.
4. **shadcn/ui** pour boutons, dialogues, formulaires, tabs, tableaux et feedback.
5. `chess.js` facultatif uniquement pour la prévalidation/optimisme UX ; `python-chess` au serveur est **source de vérité**.
6. **Pas de React Flow en V1** sauf démonstration concrète d'un besoin bloquant ; pas de recopie du PGN Viewer ou de Chessground.
7. Vérifier et pinner les versions, licences, assets et peer dependencies ; les APIs des bibliothèques changent.
8. UI intégralement locale/offline au runtime, sans fonts/CDN externes.

## Architecture attendue

- Un conteneur Linux amd64 FastAPI unique servant API + frontend statique.
- Un seul processus Stockfish actif et une file de jobs bornée, asynchrone, priorisée ; 1 worker serveur en V1.
- SQLite en volume Docker persistant `/data` avec migrations, transactions et sauvegarde sûre.
- Contrats REST `/api/v1`; flux SSE pour informations d'analyse et états, filtrés serveur selon révélation.
- Arbre PGN importé, arbre utilisateur et arbre moteur **distincts** et versionnés ; analyse source et métadonnées moteur traçables.
- Adaptateurs et modules séparés (`api`, `domain`, `persistence`, `engine`, `training`, `frontend/adapters`).
- Toute révision/position/analysis portée par identifiant immuable pour éviter les résultats périmés.
- Écoute locale Windows exclusivement sur `127.0.0.1:${HOST_PORT}` par défaut.

## Exigences algorithmiques

1. Reconstituer `chess.Board` avec historique PGN quand connu ; FEN isolée signale historique partiel.
2. Ne pas analyser position invalide ; gérer fin de partie/mat/pat, promotion, roque, en passant et nullités.
3. Utiliser `python-chess` `engine.analyse(board, Limit(...), multipv=...)` pour snapshot ou `engine.analysis(..., multipv=...)` pour streaming ; **ne pas** faire `configure({MultiPV:20})`.
4. À la racine, jusqu'à 20 **premiers coups distincts**, au plus le nombre légal. Budget et paliers 8/12/16/21.
5. Ne déclarer `depth_met` qu'après preuve explicite à profondeur >=21 ; un nombre élevé de demi-coups dans la PV ne le remplace pas. Une recherche interrompue garde `provisional`/`budget_exhausted`.
6. Branches suivantes : exploration adaptée limitée par `max_branching_children`, `max_reference_nodes`, budget total et priorité (défenses adverses, positions critiques, demandes utilisateur). Interdiction de lancer une récurrence exhaustive sans plafond.
7. Une ligne utilisateur absente du Top 20 est **réanalysable** par recherche ciblée ; son absence ne signifie jamais « fausse ».
8. Normaliser centipions au point de vue blanc pour API ; mat typé à part ; bornes de score conservées.
9. Moteur arrêté proprement sur annulation ; crash redémarrable ; aucune concurrence UCI sur même instance.
10. Entrées/sorties mises en cache avec métadonnées d'historique/engine/options pour éviter des réutilisations trompeuses.

## Exigences pédagogiques

- Mode B : échiquier **fixe**, coup moteur/score/PV indisponibles côté client avant révélation, restitution SAN textuelle facultative ; pas de note objective sans restitution.
- Mode C : ajout de coups à un parent légal, alternatives et commentaires, sous-variantes, annulation avant soumission et figement à soumission.
- Mode A : parcourir PV et sous-branches librement ; tableau classé et consultable juste sous échiquier.
- Comparer arbres avec transformations UCI/SAN, transpositions annotées et traces de preuve.
- Catégories : candidats présents/manqués, défenses manquées, suite illégale, réfutation concrète, évaluation divergente, alternative acceptable, non vérifié.
- Pas de pourcentage global arbitraire. Séparer dimensions et incertitudes ; ne pas punir une ligne différente sans réfutation vérifiée.
- Le backend **n'émet pas** des données moteur sur REST/SSE lors d'un exercice non révélé. Test de sécurité de cette condition obligatoire.

## NOUVELLES EXIGENCES — GitHub Actions et installation double-clic Windows

Lis obligatoirement **18_ACTIVER_GITHUB_ACTIONS_ET_GHCR.md**, **19_INSTALLATION_WINDOWS_DOUBLE_CLIC.md** et **20_TEMPLATES_CI_INSTALLATION_ET_CRITERES.md**, ainsi que TOUS les fichiers sous `templates/`. Ces documents précisent et, en cas de divergence, priment sur les anciennes procédures de lancement manuel en PowerShell.

- Développement de bout en bout **sur Linux**. Exécution des tests d'intégration locaux, puis publication GitHub Actions/GHCR lors des **tags vX.Y.Z** ; `workflow_dispatch` doit permettre un **test de construction sans publication**.
- Adopter `templates/github/container-release.yml` comme base puis vérifier et corriger le workflow dans le vrai dépôt. Ne pas rendre le workflow de publication dépendant d'un PAT personnel ; utiliser GITHUB_TOKEN à permissions minimales par job.
- Fabriquer dans chaque GitHub Release le fichier `ChessCalculationTrainer-Windows-vX.Y.Z.zip` et sa somme SHA256. Le ZIP contient au **premier niveau** `INSTALLER.cmd`, `OUVRIR.cmd`, `ARRETER.cmd`, `README_WINDOWS.md`, `compose.yaml`, `release-manifest.json` ; scripts PowerShell sous `scripts/windows/`.
- `INSTALLER.cmd` doit s'exécuter par double-clic après extraction, rappeler la provenance à contrôler, vérifier les prérequis, installer le bundle dans `%LOCALAPPDATA%\ChessCalculationTrainer`, tirer le conteneur GHCR **par digest**, démarrer, contrôler la santé et ouvrir le navigateur.
- Proposer installation officielle manuelle de Docker Desktop/WSL 2 si absent ; **ne jamais désactiver silencieusement les protections Windows, ni imposer Python/Node/Git**.
- Développer et tester `backup.ps1`, `update.ps1` et `uninstall.ps1` (absents des modèles par prudence) avec sauvegarde SQLite cohérente, contrôle du digest/migrations, données conservées par défaut.
- **Garder les scripts dans un véritable dossier de release stable** et créer si pertinent un raccourci bureau, pour que l'application reste utilisable après suppression du ZIP.
- Les scénarios de test G01–G06 et W01–W12 deviennent des **critères de livraison obligatoires**. La visibilité GHCR doit être PUBLIC et testée par un `docker pull` anonyme avant d'annoncer une installation publique facile.
- Si aucun véritable Windows 11 n'est accessible : rapporter ce manque, produire les tests Windows CI et marquer la gate manuelle comme **non validée**, jamais comme réussie.

## Livrables de code obligatoires

- Repo source complet et compilable.
- Frontend React/TS/Vite utilisant effectivement les composants retenus.
- Backend FastAPI/Pydantic/python-chess/Stockfish + domaine/données/test.
- SQLite migrations et exports JSON/PGN.
- Dockerfile multi-stage portable `linux/amd64`, Compose production et développement, healthcheck, utilisateur non root.
- `packaging/windows/install.ps1`, `verify.ps1`, `start.ps1`, `stop.ps1`, `update.ps1`, `backup.ps1`, `uninstall.ps1` **fonctionnels**, idempotents et testés sur autant d'environnements disponibles que possible.
- `.github/workflows/ci.yml`, publication GHCR image par digest, workflow release ZIP Windows avec manifeste et SHA256.
- README FR, guide utilisateur Windows, guide développeur Linux, SECURITY, CONTRIBUTING, LICENSE, THIRD_PARTY_NOTICES.
- Tests unitaires, intégration UCI, PGN à variations, E2E Playwright, Pester/script PowerShell et corpus pédagogique.

## Politique d'installation Windows

- L'utilisateur télécharge seulement l'archive d'installation depuis la **page Releases**.
- Vérification SHA256 et provenance de la release documentées.
- Le script vérifie WSL2/Docker Desktop/architecture/port/configuration avant toute modification.
- Il crée une configuration locale et pull l'image GHCR **par digest figé** ; démarre la stack et ouvre une URL localhost **après** healthcheck.
- Pas d'installation automatique opaque de dépendances, pas d'exécution de scripts téléchargés via pipe, pas d'élévation silencieuse, pas de modification de politique PowerShell globale.
- `uninstall.ps1` laisse les données intactes par défaut ; sauvegarde avant upgrade et stratégie restauration documentées.
- Si Windows ne peut pas être testé localement, **ne mens pas** : implémente et teste statiquement, puis signale le test Windows réel comme gate manuel non passé.

## Qualité et sécurité

- Figer la licence du projet après vérification des compatibilités, GPL Stockfish et obligations redistributives ; ne pas faire d'affirmation juridique définitive sans fondement.
- Respecter limtes PGN/arbres/queue/budget, protections Origin/Host/CSRF et non root ; pas d'XSS dans les commentaires.
- Les états moteur partiels/inconnus sont représentés sans tromper l'utilisateur.
- Ne pas dépendre d'une connexion Internet une fois l'application installée.

## Méthode de travail demandée

Travaille en **lots successifs** selon `13_PLAN_IMPLEMENTATION.md`. Chaque lot doit produire code concret et tests, pas une nouvelle séance de spécification :

0. Analyse initiale de l'environnement Linux / outils disponibles ; vérifier versions et dépendances en ligne si possible.
1. Spike UI + Stockfish fonctionnel ; valider APIs réelles.
2. Noyau du domaine, import FEN/PGN, sessions et base.
3. Modes B/C anti-spoiler, puis analyse progressive et mode A.
4. Arbre adaptatif, débriefing et export.
5. Tests, sécurité, accessibilité, performance.
6. Docker/CI/GHCR/bundle Windows/release ; documentation complète.

Dès que tu disposes des permissions de fichier et shell, implémente directement. Évite de multiplier les questions de confort ; prends les défauts explicites de `17_DECISIONS_DEFAUTS.md`. Si une information indispensable manque (par exemple droits de push GitHub), implémente quand même le maximum, puis demande uniquement l'action vraiment bloquante.

## Critères de réussite imposés

Exécute les tests listés dans `11_TESTS_ACCEPTATION.md`, notamment T01–T18 et P01–P12. Fournis un rapport final :

1. fonctionnalités réalisées, références commits/files,
2. commandes exactes de lancement Linux et Windows,
3. sorties de tests réellement exécutés,
4. chemin des assets publiés ou commandes de publication si accès GitHub absent,
5. versions réelles moteur, libs, image digest,
6. limites, risques résiduels et tests non exécutables dans ton environnement,
7. guide de validation manuelle Windows.

**N'affirme jamais que le logiciel Windows est installé, testé ou publié sans preuve.**

## Tests d'acceptation supplémentaires du comportement échiquéen

- FEN d'exemple fournie par l'utilisateur : `rb1qkb1r/pp3ppp/2n1pn2/2pp4/3P4/2NQPN2/PPP2PPP/R1B1K2R w KQkq - 0 1` : valider, reconstruire et analyser si position conforme aux règles de validation.
- Position terminale : zéro ligne.
- Position avec <20 coups légaux : pas de duplication fictive.
- Position avec >20 coups : limites et message de couverture partielle.
- PGN incluant sous-variantes récursives et commentaires : import/export correct.
- Proposition humaine non Top 20 : autoriser vérification ciblée, sans la traiter comme erreur.
- Recherche interrompue avant depth=21 : ne jamais afficher `21/21` ou jugement définitif injustifié.
- Séance mentale non révélée : inspecter le réseau avec Playwright, aucune PV/score accessible, même dans données en cache ou endpoints auxiliaires.

## Exigence finale

Ne livre **pas** un squelette vide. Vise une V1 intégralement utilisable, avec dépôt propre et workflows de publication. Si le temps disponible est limité, livre une verticale complète testée (position → exercice B/C → recherche → révélation → diagnostic → sauvegarde), marque honnêtement les éléments restants et poursuis tant que les outils le permettent.
