# 06 — Moteur Stockfish : protocole d'analyse et exploration adaptive

## Version, compilation et architecture CPU

- **Version de départ : Stockfish 19 stable**, tag Git officiel `sf_19`, et non `master`/nightly.
- Construire ou embarquer dans une **image Linux amd64**. Le binaire doit fonctionner avec le jeu d'instructions minimal garanti sur les PC cibles. **Ne pas** compiler `-march=native` sur le runner Linux pour ensuite l'exécuter sur des CPU Windows arbitraires.
- Recommandation V1 : utiliser le code source Stockfish depuis le tag officiel figé, compiler avec une cible x86-64 générique supportée par le Makefile (`make help` et documentation propres à la version) puis effectuer `bench`, démarrage UCI et un test de position au build.
- Si les binaires universels officiels Linux amd64 sont utilisés : vérifier l'archive, l'empreinte, le support CPU et les conditions de redistribution ; ne pas mélanger variantes AVX2 non compatibles.
- **Important :** le binaire moderne Stockfish utilise NNUE. Préserver les fichiers réseaux compatibles ; tester `uci`/`isready`/`go depth 8` et vérifier toute erreur de chargement avant la release.
- Enregistrer `engine_id`, tag, hash source, `engine bench`, version NNUE et paramètres de build. Prévoir une mise à jour par release, pas une installation automatique silencieuse.

## Paramètres de départ

| Paramètre | Défaut proposé | Politique |
|---|---:|---|
| `target_depth` | 21 | réglable 8..32 ; 21 par défaut |
| `root_candidates_max` | 20 | maximum, `min(20, nb coups légaux)` |
| `stages` | 8, 12, 16, 21 | paliers d'information, pas garantie de durée |
| `threads` | min(2, CPU utilisables moins une marge) ; jamais < 1 | borné selon conteneur/cgroups et paramètre explicite |
| `hash_mb` | 128 MiB | borné à une fraction raisonnable de la RAM allouée |
| `root_budget_seconds` | 300 | plafond par défaut de l'effort racine ; non promesse de depth 21 |
| `tree_budget_seconds` | 300 | plafond additionnel par séance pour les expansions automatiques |
| `max_reference_nodes` | 80 | anti-explosion, configurable |
| `max_branching_children` | 3 | point de départ, 0 pour terminal |
| `engine_instances` | 1 | un job actif ; pas de workers concurrents |

Les budgets sont **valeurs de conception**, à valider par bench. Un utilisateur peut lancer volontairement un approfondissement au-delà du budget par défaut.

## Protocole initial

```text
1. Reconstituer l'état légal complet (PGN/history si disponible).
2. Si échec et mat/pat/position terminée, signaler qu'aucune PV n'est disponible.
3. Énumérer les coups légaux ; capter leur cardinalité.
4. Analyser MultiPV = min(20, legal_count) par stages croissants.
5. Émettre des snapshots provisoires distincts par premier coup UCI.
6. Pour chaque ligne, conserver profondeur rapportée, bornes de score,
   stats, PV UCI et configuration UCI.
7. Arrêter au budget, sur annulation ou quand la profondeur cible est
   attestée pour les lignes pertinentes (ne pas inventer les lignes absentes).
8. Marquer le résultat final/partiel avec causes et restrictions.
9. Construire un arbre initial basé sur les PV puis planifier les besoins
   de sous-branches critiques sous budget séparé.
```

### Exemple Python `python-chess` (schématique mais API correcte)

```python
import chess
import chess.engine

async def analyse_root(engine, board: chess.Board, root_max: int = 20):
    if not board.is_valid():
        raise ValueError('Position invalide')
    n = board.legal_moves.count()
    if n == 0:
        return []
    multipv = min(root_max, n)
    # Pour un résultat ponctuel :
    results = await engine.analyse(board, chess.engine.Limit(depth=21), multipv=multipv)
    # Une application interactive doit plutôt utiliser engine.analysis(...)
    # et lire ses info successives avec annulation et temps/budget contrôlés.
    return results
```

**Ne pas** faire `engine.configure({'MultiPV': 20})` avec `python-chess` : passer `multipv` à l'appel d'analyse. L'interface `engine.analysis` et les objets `InfoDict` doivent être utilisés correctement selon la version figée. Lors de l'annulation, terminer proprement le contexte d'analyse, puis attendre `isready`/redémarrer le moteur si son état UCI est incertain.

## Profondeur : sens précis

- `depth` = profondeur de la recherche UCI annoncée par Stockfish pour les informations courantes.
- `seldepth` = profondeur sélective ; **pas** un substitut au critère `depth>=21`.
- `len(PV)` = nombre de coups UCI listés ; peut différer de 21 même quand depth=21.
- Développer un sous-arbre à 21 demi-coups **depuis l'exercice** est un objectif distinct : ne pas confondre `local_depth=21` au nœud intermédiaire avec la distance de 21 demi-coups depuis la racine.
- Attention à MultiPV : les informations peuvent provenir d'itérations, de lignes et de bornes d'évaluation différentes. N'afficher « profondeur 21 atteinte pour les 20 lignes » que si des entrées exploitables existent pour chacune avec profondeur attestée au palier visé. Sinon état partiel explicite.

## Défenses et coups critiques : algorithme borné

**Fonction de classement exploratoire**, pas oracle :

1. Construire les lignes candidates en gardant jusqu'à 20 coups initiaux.
2. Détecter les nœuds où les PV divergent ou où une réponse adverse alternative pourrait affecter significativement l'évaluation.
3. À chaque nœud prioritaire, demander une recherche MultiPV limitée (par défaut 2 ou 3) pour le **camp au trait**, avec une profondeur locale cohérente et un budget.
4. Inclure les réponses adverses qui semblent les plus difficiles et les contre-coups tactiques **après vérification par le moteur** ; présence d'échec/capture n'est pas une preuve de pertinence.
5. Vérifier les branches du joueur absentes de l'arbre, même si le premier coup est hors Top 20, via `root_moves` ciblés ou analyse à partir de la position jouée.
6. Prioriser à la racine, aux positions critiques, aux lignes saisies par l'utilisateur et aux positions à fortes oscillations d'évaluation ; arrêter selon plafonds d'effort et nœuds.
7. Les branches non explorées ou élaguées par politique gardent ce statut ; ne jamais les étiqueter « mauvaise variante ».

### Priorité des travaux (proposition)

`user_requested_reanalysis > unverified_user_branch > opponent_critical_reply > root_depth_upgrade > low_information_expansion`, avec équité : un job de fond ne doit pas être affamé indéfiniment. Dédupliquer les requêtes de calcul strictement équivalentes ; aucune exploration récursive sans contrôle explicite `max_nodes` + `budget`.

## Signification des évaluations

Enregistrer `Score.pov(chess.WHITE)` sans transformer les mats en centipions artificiels. `Mate(+N)` et `Mate(-N)` gardent un type distinct. Les centipions Stockfish ne constituent pas des probabilités de gain. Les bornes `lowerbound`/`upperbound` ne doivent pas être présentées comme valeurs exactes.

Pour classer le meilleur coup, utiliser le point de vue du **camp au trait à la position analysée** ; pour l'UI, normaliser ensuite au point de vue blanc ou avec préférence utilisateur. Ne jamais inverser les évaluations deux fois lorsque le camp noir joue.

## Conditions terminables

- Échec et mat, pat, matériel insuffisant : pas de continuation légale.
- Règles 50/75 coups et répétitions : utiliser le contexte effectivement connu, distinguer claimable/automatique ; ne pas inventer une répétition précédente pour FEN isolée.
- PGN pouvant contenir position historique : chaque analyse doit partir d'un `Board` reconstruit et copié avec pile pertinente (`copy(stack=True)` par défaut selon version), pas d'un FEN isolé si historique connu.
- Effort très coûteux : montrer progrès/CPU/budget sans prétendre quantifier précisément un pourcentage de profondeur restante.

## Robustesse et tests moteur obligatoires

Cas : `0/1/2/20/>20` coups légaux ; mat en 1 ; mat annoncé ; score borné ; promotion ; capture en passant ; roque ; trois répétitions ; position invalide ; arrêt en plein MultiPV ; deux positions enchaînées rapidement ; crash moteur ; CPU 1 cœur ; migration moteur ; UI étalée sur plusieurs sessions.
