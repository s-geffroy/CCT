# 20 — Modèles fournis, règles d'intégration et nouveaux tests d'acceptation

Ce document complète `09`, `10`, `11`, `14`, `16`, `18` et `19` sans remplacer les décisions D1–D7. **Tous les fichiers `templates/` sont des points de départ pour le LLM implémenteur : ils ne forment pas un logiciel exécutable ni une release effective.** Ils doivent être intégrés, adaptés, testés, puis seulement publiés dans le vrai dépôt GitHub du projet.

## 1. Inventaire des modèles inclus dans ce ZIP

| Modèle | Destination dans le futur dépôt | Fonction |
|---|---|---|
| `templates/github/container-release.yml` | `.github/workflows/container-release.yml` | CI image Linux amd64, push GHCR sur tag, création ZIP Windows + SHA256 |
| `templates/windows/INSTALLER.cmd` | `packaging/windows/INSTALLER.cmd` | Point d'entrée Windows par double-clic |
| `templates/windows/OUVRIR.cmd` | `packaging/windows/OUVRIR.cmd` | Démarrer et ouvrir le navigateur |
| `templates/windows/ARRETER.cmd` | `packaging/windows/ARRETER.cmd` | Arrêter sans supprimer les données |
| `templates/windows/verify.ps1` | `packaging/windows/verify.ps1` | Contrôles WSL, Docker, OS, RAM et disque |
| `templates/windows/install.ps1` | `packaging/windows/install.ps1` | Installation par digest GHCR + volume, santé et raccourci |
| `templates/windows/start.ps1` | `packaging/windows/start.ps1` | Ouverture après disponibilité |
| `templates/windows/stop.ps1` | `packaging/windows/stop.ps1` | Arrêt sûr |
| `templates/windows/compose.yaml` | `compose.yaml` | Stack de production sous localhost |
| `templates/windows/README_WINDOWS.md` | `packaging/windows/README_WINDOWS.md` | Notice de l'installateur Windows |

Le workflow exige en outre **`update.ps1`, `backup.ps1`, `uninstall.ps1`**, absents des modèles car leur réalisation correcte dépend du vrai modèle SQLite et des migrations de l'application. **L'implémenteur doit les coder et les tester avant qu'une release puisse passer.** Ne pas remplacer ces fichiers par des scripts vides : les tests doivent vérifier une sauvegarde restaurable et le maintien des données lors des mises à jour.

## 2. Intégration Linux par le LLM

Dans le dépôt logiciel qu'il crée réellement, il peut démarrer par :

```bash
mkdir -p .github/workflows packaging/windows
cp /chemin/vers/specs/templates/github/container-release.yml .github/workflows/container-release.yml
cp /chemin/vers/specs/templates/windows/*.cmd packaging/windows/
cp /chemin/vers/specs/templates/windows/*.ps1 packaging/windows/
cp /chemin/vers/specs/templates/windows/README_WINDOWS.md packaging/windows/
cp /chemin/vers/specs/templates/windows/compose.yaml ./compose.yaml
```

Il doit ensuite ajuster **le Dockerfile, le Makefile, les migrations, les routes de santé, les versions d'actions et le packaging**. Les modèles supposent `backend/Dockerfile` avec `context: .`, `make ci`, `/api/v1/health/ready` et un Python dans l'image finale.

## 3. Tests nouveaux, nécessaires pour la release

| ID | Test | Seuil de réussite |
|---|---|---|
| G01 | Workflow activé, `workflow_dispatch` depuis main | Job `build` vert sans publication |
| G02 | Push PR externe | Aucun package/release publié, secrets inutiles |
| G03 | Push tag vX.Y.Z | Image Linux amd64, digest 64 hex, release complète |
| G04 | Intégrité ZIP | Checksum calculé après zip, identique au téléchargement |
| G05 | GHCR public | `docker pull` anonyme **sans** docker login |
| G06 | Pinned image | `.env` contient exclusivement digest OCI, pas `latest` |
| W01 | Windows installé Docker déjà opérationnel | Double-clic install, healthcheck vert, navigateur ouvert |
| W02 | Première installation Docker absent | Message + lien officiel, aucune fausse réussite |
| W03 | Windows Docker arrêté/mode Windows | Diagnostic déterministe ; pas de modification des autres stacks |
| W04 | Réinstallation même digest | Idempotent ; arbre utilisateur et historique conservés |
| W05 | Nouvelle version via INSTALLER.cmd | Mise à jour bloquée ; dirige vers procédure de migration |
| W06 | Arrêt par ARRETER.cmd | Docker `stop`, volume et données préservés |
| W07 | Port localhost | Non visible depuis réseau externe |
| W08 | Raccourci / chemin utilisateur accentué | Ouverture correcte, sans dépendance au ZIP temporaire |
| W09 | Sauvegarde avant update | Snapshot SQLite cohérent, restauration vérifiée |
| W10 | Désinstallation normale | Pas de `docker compose down -v` par défaut |
| W11 | CI tests Windows | Analyse PowerShell/Pester + contrôle statique `.cmd` |
| W12 | Vrai poste Windows 11 x64 | Rapport de test avec version Docker/WSL, date et logs |

La gate de qualité du dépôt doit combiner : tests Python, tests TypeScript, Playwright, smoke de **l'image finale**, simulation PowerShell sous CI Windows, et essai manuel réel Windows 11 avant la première annonce publique.

## 4. Invariants du packaging

1. L'image est publiée avant la génération du manifeste.
2. Le manifeste reprend le **digest rendu par `build-push-action`**, sans préfixe fictif.
3. Les `.cmd` sont à la racine du ZIP ; les `.ps1` sont sous `scripts/windows/`.
4. Les chemins du `compose.yaml`, de `.env` et des fichiers app pointent vers `%LOCALAPPDATA%/ChessCalculationTrainer` après installation.
5. Aucun outil de compilation n'est demandé au poste Windows.
6. L'application est exposée sur `127.0.0.1` uniquement ; pas de réseau local ouvert.
7. L'image OCI contient Stockfish et les réseaux NNUE compatibles (redistribution GPL documentée) ; aucune récupération réseau au runtime.
8. Aucun script ne force un redémarrage Windows ou une élévation de privilèges sans autorisation de l'utilisateur.
9. Un succès est conditionné à une sonde `ready` positive, non à un simple code de retour de `docker compose up`.
10. La release n'est dite installable publiquement qu'après passage du package GHCR à `Public` et test anonyme.

## 5. Corrections à appliquer au dossier précédent

- `10_PUBLICATION_GITHUB_WINDOWS.md` présentait une installation PowerShell en ligne de commande. **L'expérience par défaut est désormais le double-clic `INSTALLER.cmd`** du document 19 ; la voie PowerShell demeure une option technique.
- `09_DEVELOPPEMENT_LINUX_DOCKER.md` proposait la structure `packaging/windows/*.ps1`, conservée dans le dépôt source, mais **les scripts sont réorganisés sous `scripts/windows/` dans le ZIP de release**.
- Les fichiers ci-dessus doivent être **complétés par l'implémentation**, pas copiés tels quels en prétendant que l'application existe.
- Le script lance PowerShell avec `-ExecutionPolicy Bypass` limité au processus explicitement déclenché par double-clic. Aucune modification permanente de stratégie ni désactivation de SmartScreen n'est autorisée. Les politiques de groupe (GPO) peuvent rendre ce lancement impossible : arrêt propre et assistance administrateur.
- La recommandation de conserver l'option GitHub `Workflow permissions` globale en lecture reste compatible avec l'écriture de certains jobs uniquement via le champ `permissions` du workflow, sous réserve des restrictions d'organisation.

## 6. Contrôle statique de ces modèles

Le ZIP de spécifications doit être vérifié avec une lecture YAML par un parseur, un test de présence des modèles et un contrôle de cohérence des chemins. **Ces vérifications ne remplacent pas l'exécution d'un job GitHub Actions sur le vrai dépôt, ni un test d'installation Windows**, qui nécessitent la présence du logiciel et des systèmes appropriés.
