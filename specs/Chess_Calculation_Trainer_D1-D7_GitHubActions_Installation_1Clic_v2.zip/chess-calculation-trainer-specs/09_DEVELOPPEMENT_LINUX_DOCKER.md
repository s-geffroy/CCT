# 09 — Développement Linux, build Docker et reproductibilité

## Environnement de développement

OS Linux (Ubuntu/Debian ou équivalent récent) ; Docker Engine + Compose v2 + Git ; Node LTS compatible avec versions React/Arborist sélectionnées ; Python version maintenue (3.12 conseillé, à valider selon dépendances). Le LLM peut utiliser `uv` pour la gestion Python et `npm ci` ou `pnpm --frozen-lockfile` côté frontend. Conserver les lockfiles.

Installer et vérifier localement :

```bash
git --version
docker version
docker compose version
python3 --version
node --version
```

## Dossiers recommandés du dépôt à produire

```text
chess-calculation-trainer/
├── README.md
├── LICENSE
├── THIRD_PARTY_NOTICES.md
├── CHANGELOG.md
├── SECURITY.md
├── CONTRIBUTING.md
├── .gitignore
├── .env.example
├── compose.yaml                # production, image depuis GHCR
├── compose.dev.yaml            # développement Linux
├── Makefile
├── backend/
│   ├── Dockerfile
│   ├── pyproject.toml
│   ├── uv.lock (ou lock équivalent)
│   ├── app/
│   │   ├── main.py
│   │   ├── api/
│   │   ├── domain/
│   │   ├── persistence/
│   │   ├── engine/
│   │   ├── training/
│   │   └── settings/
│   └── tests/
├── frontend/
│   ├── package.json
│   ├── package-lock.json
│   ├── src/
│   │   ├── components/
│   │   ├── features/
│   │   ├── adapters/
│   │   └── api/
│   └── tests/
├── tests/
│   ├── fixtures/
│   ├── e2e/
│   └── acceptance/
├── packaging/
│   ├── windows/
│   │   ├── install.ps1
│   │   ├── start.ps1
│   │   ├── stop.ps1
│   │   ├── update.ps1
│   │   ├── backup.ps1
│   │   ├── uninstall.ps1
│   │   └── verify.ps1
│   └── release-manifest.schema.json
├── .github/workflows/
│   ├── ci.yml
│   ├── container.yml
│   └── release.yml
└── docs/
    └── architecture-implementation.md
```

## Image applicative

**Une image Linux amd64 multi-stage :**

1. Node builder : installe lockfile, compile Vite sans requête réseau au runtime.
2. Stockfish builder : récupère **archive exacte tag `sf_19`** avec SHA256, compile en mode générique portable, charge les NNUE compatibles, teste `bench`.
3. Backend builder : installe dépendances Python à versions figées.
4. Runtime minimal : FastAPI + assets UI + exécutable Stockfish + réseaux NNUE + dépendances runtime ; utilisateur non root ; répertoire `/data` writable uniquement en volume.

Pas d'`apt-get install stockfish` non figé. Pas de téléchargement d'un `master.tar.gz` depuis `https://github.com`. Pas de `make -march=native` non portable. Les images Docker builder et runtime doivent être épinglées par digest dans la version livrée si possible.

## Exigences de build

- `docker build --platform=linux/amd64 ...` ; uniquement AMD64 en release initiale.
- Installer les bibliothèques partagées indispensables ; `ldd /usr/local/bin/stockfish` et smoke test depuis **l'image finale**.
- Exécuter une recherche UCI de profondeur 8 sur au moins une position de test.
- Construire assets frontend à l'avance, sans CDN ; contrôler headers et cache.
- Séparer la configuration stable de l'état utilisateur ; image immuable, `/data` persistant.
- `HEALTHCHECK` qui vérifie l'API et la disponibilité de la base ; readiness signale moteur UCI KO.
- Lancer 1 worker backend pour garder un unique planificateur.

## Développement itératif

```bash
make lint
make test
make e2e
make build
make smoke
```

Les commandes ci-dessus **sont des contrats à implémenter dans le Makefile**, pas des commandes déjà disponibles dans ce dossier de spécifications.

## Test cross-platform de l'image

La cible Windows exécute un **conteneur Linux** ; Linux et Windows partagent donc les mêmes binaires Linux sous AMD64 dans Docker. Toutefois, le test Linux **ne suffit pas** à valider Docker Desktop, WSL 2, l'emplacement des volumes, les scripts PowerShell, les permissions ou l'ouverture navigateur Windows. Conserver une **checklist de test manuel Windows réel** et, si possible, une CI runner Windows pour syntaxe PowerShell et étapes mockées.

## Optimisation avant changement d'architecture

Profiler les recherches et l'UI avant d'ajouter un deuxième worker/Redis. Pour augmenter la performance Stockfish, mesurer d'abord le passage de Threads=1 à 2/4, hash 64/128/256 MiB, frais de lancement du moteur, coût MultiPV=20, économies du cache. Garder une marge CPU pour que Windows reste utilisable.
