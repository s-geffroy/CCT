# 02 — Architecture technique

## Architecture cible

```text
Windows 11 x64 / navigateur : localhost:8765
    │  UI React/TypeScript statique, vendorizée et servie localement
    │  REST JSON pour commandes ; SSE pour progrès / diagnostics autorisés
    ▼
Conteneur Linux amd64 unique (FastAPI/Uvicorn, utilisateur non root)
    ├─ validation et import : python-chess
    ├─ exercice : contrôleur modes A/B/C, aucun spoiler involontaire
    ├─ modèle d'arbres : joueur, PGN d'origine, référence moteur séparés
    ├─ planificateur : file bornée, priorité/réservations, annulation
    ├─ adaptateur UCI : 1 processus Stockfish 19 stable
    ├─ comparaison pédagogique avec limites de confiance
    └─ SQLite /data/app.sqlite (volume Docker persistant)
```

## Développement vs exploitation

- **Linux développeur :** `docker compose -f compose.dev.yaml` ou `uv run` + Vite ; commande unique documentée `make dev`, `make test`, `make build`.
- **Windows utilisateur :** PowerShell local extrait d'une archive officielle du projet → contrôle WSL/Docker → `docker compose pull` d'image `ghcr.io/OWNER/REPO@sha256:...` ou tag immuable de release (digest préféré) → démarrage → ouvre navigateur.
- **Publication :** GitHub Actions Ubuntu construit/tests/image, puis publie release avec bundle installable et image indiquée dans un manifeste.
- **Aucune compilation locale** Windows et aucune installation de Python/Node/Git exigée pour l'utilisateur.

## Processus et concurrence

- 1 conteneur FastAPI, 1 seul processus serveur Uvicorn en V1. Une file persistante légère et un gestionnaire de recherche dans ce processus suffisent.
- Ne jamais démarrer plusieurs workers Uvicorn sans extraire le planificateur : chaque worker lancerait son Stockfish et casserait l'unicité.
- Un processus Stockfish actif à la fois. Les analyses sont sérialisées et priorisées ; il peut être redémarré après crash.
- Pour éviter l'obstruction du serveur, utiliser `asyncio`/API asynchrone `chess.engine.popen_uci()` et itération de `engine.analysis(...)`, ou un thread supervisé uniquement si indispensable. Ne pas partager un `SimpleEngine` dans des threads concurrents.
- Backend construit des **instantanés immuables** de positions au lancement de chaque travail.
- Le navigateur n'est pas propriétaire de la vérité du moteur ; toutes les réponses portent `position_id`, `analysis_id`, `session_id` et révision.

## Flux d'entraînement sans spoiler

1. L'utilisateur sélectionne une position, avec un historique PGN éventuel.
2. La séance est créée et verrouille `root_position_snapshot` et `root_history` ; mode B ou C.
3. La recherche peut être préparée au serveur sans transmettre les scores/coups au navigateur tant que `revealed_at = null`.
4. Les événements publics avant révélation contiennent uniquement `status`, `progress_category`, `is_ready`, pas `best_move`, `pv`, `score`, `mate`, `rank`, `target_move`.
5. Le joueur saisit son arbre / ses évaluations / son autoévaluation ; le backend conserve un instantané de soumission.
6. Débriefing seulement après `POST /sessions/{id}/reveal` ; lecture explicite des analyses et comparaison.
7. L'utilisateur peut explorer l'arbre et demander des vérifications ciblées de lignes oubliées, selon politique de débriefing.

**Sécurité clé :** cacher des données côté CSS n'est pas une prévention de fuite. Les données moteur ne doivent pas être émises par API/SSE avant révélation.

## Position et répétition

Une FEN porte les pièces, le trait, droits de roque, possibilité de prise en passant et compteurs, mais pas l'historique complet des coups ; l'historique est essentiel notamment pour la répétition. Maintenir une `root_board` + `uci_history` / branche depuis une partie PGN. Pour les FEN isolées : signaler `historique incomplet` et ne pas prétendre connaître les répétitions antérieures.

Les transpositions peuvent être liées à des fins de navigation/cache si leur **contexte de règles** est compatible ; ne jamais fusionner destructivement deux nœuds d'arbres du joueur pour le seul motif que leur placement des pièces est identique.

## Composants frontend

- `PositionWorkspace`: origine FEN/PGN/éditeur.
- `ChessboardPanel`: `react-chessboard` en mode observation / saisie / édition.
- `CandidatesTable`: jusqu'à 20 lignes PV classées et cliquables **sous** l'échiquier.
- `VariationTree`: `react-arborist` contrôlé, arborescence avec SAN, annotation.
- `TrainingTimer`: chronomètre facultatif, jamais perturbant.
- `TrainingSession`: mode B/C, anti-spoiler, sauvegarde.
- `ReviewPanel`: diagnostic et actions de réanalyse.
- `SettingsPanel`: threads, hash, budgets, profondeurs, mode d'analyse.

## Persistance et migrations

SQLite en volume `/data` ; journalisation WAL selon validation du FS Docker ; connexion avec `busy_timeout` et transaction courte. Schémas évolutifs via Alembic ou système de migrations versionnées déterministes. Export JSON/PGN accessible sans abonnement ni cloud. À chaque mise à jour, sauvegarde de la base recommandée avant migration destructive.

## Interface réseau

- `ports: ["127.0.0.1:8765:8000"]` (port hôte personnalisable).
- L'app dans le conteneur peut écouter `0.0.0.0:8000` ; seule la publication Docker loopback protège la cible Windows.
- Refuser les origines inattendues pour les mutations et les flux SSE. Pas de CORS wildcard.
- Aucun téléchargement automatique de scripts distants lors du démarrage ; les paquets UI sont dans le bundle.

## Critères de simplification

Ne pas ajouter un service frontend Nginx si FastAPI peut servir les assets de build via Starlette StaticFiles avec fallback SPA sûr. Éviter un deuxième conteneur sauf besoin de profilage/protection justifié. Ne pas ajouter un bus de messages externe. Tout changement doit être motivé par un test qui échoue ou un objectif mesurable.
