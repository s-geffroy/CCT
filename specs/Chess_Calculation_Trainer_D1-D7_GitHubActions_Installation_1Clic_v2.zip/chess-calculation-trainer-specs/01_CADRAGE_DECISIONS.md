# 01 — Cadrage, décisions D1–D7 et périmètre

## Produit

Application de **pratique délibérée du calcul échiquéen**. Depuis une position saisie/importée, le joueur calcule mentalement ou consigne un arbre personnel, puis confronte ses variantes avec un arbre de référence produit de façon sélective et progressive à partir de Stockfish.

Ce n'est **pas** seulement un analyseur MultiPV, ni un générateur exhaustif de toutes les lignes d'une profondeur donnée.

## Décisions utilisateur validées

| ID | Arbitrage verrouillé | Conséquences |
|---|---|---|
| D1 | Windows comme cible finale, Docker | Docker Desktop + WSL 2 ; scripts PowerShell, navigateurs habituels |
| D2 | Entrées FEN + PGN + éditeur d'échiquier | positions libres, partie à variations, sélection de demi-coups |
| D3 | Arbre de calcul ramifié | état nodal, variations, navigation et annotations |
| D4 | 3 modes, priorité B (mental) et C (arbre personnel) | interdiction d'aide prématurée, parcours distincts |
| D5 | Restitution hybride | texte facultatif pour B, arbre interactif pour C, comparaison et progression |
| D6 | Référence Stockfish hybride adaptative | 20 candidats racine au plus, défenses critiques, réanalyse des branches joueur |
| D7 | Calcul progressif | résultats provisoires, enrichissement graduel, interruption et budgets |

**Contrainte supplémentaire du propriétaire :** le LLM code **sous Linux** et publie un dépôt **GitHub public** ; l'utilisateur final installe sur **Windows depuis une GitHub Release**, sans environnement de développement.

## Objectifs mesurables

- Importer et éditer toute position orthodoxe analysable ; expliquer les positions non analysables.
- Proposer un exercice sans fuite des solutions.
- Calculer progressivement jusqu'à une profondeur cible 21, avec jusqu'à 20 premiers coups sélectionnés.
- Permettre l'exploration et la création d'arbres avec variations et sous-variations.
- Comparer les branches restituées au moteur et distinguer **coups omis**, **défenses manquées**, **erreurs de légalité**, **divergences raisonnables** et **faiblesses d'évaluation**.
- Sauvegarder localement exercices, résultats et sessions.
- Installer sans compilation sur Windows lorsque Docker Desktop/WSL 2 et l'image publique préconstruite sont disponibles.

## Définition du MVP (V1 publiable)

1. FEN, PGN (variantes comprises), éditeur standard ; sélection position.
2. Modes B mental et C construction d'arbre, sans aide moteur avant débriefing.
3. Mode A étude libre simple, avec tableau des meilleures variantes **sous l'échiquier**.
4. Recherche progressive de référence, jusqu'à 20 candidats initiaux, profondeur cible 21, calcul local limité/arrêtable.
5. Sous-branches adaptatives et réanalyse de toute branche utilisateur valide non couverte.
6. Débriefing interprétable, sans score arbitraire unique, historique SQLite.
7. Tests, Docker, CI Linux, publication GHCR, bundle Release et installateur Windows.

## Hors périmètre V1

Chess960, variantes non standard, moteurs GPU, connexion aux plateformes de jeu, cloud/multijoueur, tutorat automatique par LLM, OCR d'échiquier, ouverture de ports réseau, serveur multi-utilisateur, calibration scientifique d'un « score cognitif ».

## Principes de conception

- **Vérité échiquéenne serveur :** `python-chess` valide toute mutation persistée.
- **Références probabilistes :** les coups et évaluations d'un moteur à profondeur 21 ne sont pas des certitudes mathématiques.
- **Aucune fuite de solution :** backend distingue données d'entraînement et données d'analyse non révélées.
- **États explicités :** inconnu / non exploré / provisoire / terminé / budget dépassé / interrompu / erreur.
- **Reproductibilité :** versions, poids NNUE, options moteur et contraintes de recherche inscrits en base.
- **Simplicité :** un conteneur applicatif et SQLite, un seul moteur actif. Pas de microservices, Redis ou PostgreSQL.
- **Sobriété et disponibilité :** fonctionne hors ligne après l'installation (hors première image et mises à jour).
