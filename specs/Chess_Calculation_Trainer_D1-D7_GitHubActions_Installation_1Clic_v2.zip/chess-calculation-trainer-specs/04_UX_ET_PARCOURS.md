# 04 — UX détaillée et parcours d'entraînement

## Principe : l'échiquier au centre, les 20 variantes juste en dessous

Disposition desktop conseillée :

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ [Positions] [Entraînement] [Explorer] [Historique] [Réglages]              │
├───────────────────────────┬──────────────────────────────────────────────────┤
│                           │  Modes : mental B | arbre C | explorer A        │
│      ÉCHIQUIER            │  Arbre personnel / référence (selon révélation) │
│      8 x 8                │  [replier] [développer] [commenter]              │
│                           │  1. ...                                          │
│ [◀◀] [◀] [▶] [▶▶] [↺]     │  Notes, estimation, chrono facultatif           │
├───────────────────────────┴──────────────────────────────────────────────────┤
│ VARIANTES STOCKFISH — SOUS L'ÉCHIQUIER ET LE PANNEAU D'ARBRE                │
│ Affichées en étude libre / débriefing ; jamais pendant calcul non révélé   │
│ # | 1er coup SAN | éval. blanche/trait | profondeur | PV | état            │
│ 1 | ...          | ...                 | 21/21       | ...| terminée        │
│ 2 | ...          | ...                 | 17/21       | ...| provisoire      │
│ ... maximum 20 entrées                                                   │
└──────────────────────────────────────────────────────────────────────────────┘
```

En écrans étroits, empiler échiquier, tableau, arbre et notes. Ne jamais cacher le tableau dans un onglet non découvrable après révélation : exigence fondatrice de l'utilisateur.

## Module « Positions »

Trois onglets synchronisés :

1. **FEN :** coller, valider, confirmer trait et métadonnées.
2. **PGN :** coller/importer, choisir partie en cas d'archive multiple, afficher les variations et naviguer ; afficher erreurs et avertissements de parsing plutôt que les masquer.
3. **Éditeur :** échiquier + pièces libres, changer trait, roque, en passant, compteurs, position initiale/vider/retourner.

Une modification libre de la position **crée un nouvel instantané** et ne prétend pas continuer l'historique PGN. Dans ce cas l'interface signale que les informations de répétition peuvent être perdues.

## Mode B — Calcul mental strict (priorité 1)

1. Position fixe, orientation au choix ; chronomètre **facultatif**.
2. Aucune flèche, évaluation, PV ni meilleur coup moteur. Interdiction des déplacements sur l'échiquier.
3. Zone « mes coups candidats » en SAN textuelle **facultative** ; si l'utilisateur veut rester mental, champ masquable.
4. Bouton `J'ai terminé` → autoévaluation optionnelle (« mes candidats », « menace principale », « estimation de la position ») → verrouille la tentative → `Révéler`.
5. Débriefing séquencé : candidats, réponses adverses, comparaison complète, points à retravailler. Le joueur peut choisir `Révéler` sans avoir fourni de lignes, mais ne reçoit alors aucun diagnostic automatique de calcul.
6. Une nouvelle tentative sur la même position est une nouvelle session. Le moteur ne modifie jamais un arbre déjà soumis.

## Mode C — Construction d'arbre (priorité 1)

1. Afficher l'échiquier à la position correspondant au nœud sélectionné.
2. Ajouter un coup via clic, glisser-déposer ou notation SAN ; toujours valider sur le serveur.
3. Ajouter une alternative en sélectionnant un parent existant ; créer une branche distincte.
4. Annotation facultative d'évaluation humaine (avantage blanc, avantage noir, égalité, initiative, attaque, incertain), et commentaire libre.
5. Possibilité d'annuler/rétablir **les modifications de l'arbre en cours de séance** ; après soumission, figer la version.
6. `Terminer mon calcul` puis comparer, avec nœuds : concordant, oublié, déviant mais acceptable, erreur critique, inconnu/non évalué.
7. Aucun clic sur un coup personnel ne doit montrer l'évaluation moteur avant révélation.

## Mode A — Exploration libre (priorité 2)

- Afficher jusqu'à 20 entrées racine dans le tableau juste sous l'échiquier.
- Cliquer une ligne → affichage de la première position après le coup ; curseur sur la PV ; navigation avant/arrière.
- Ouvrir des sous-branches, demander « analyser cette réponse », « explorer les défenses ».
- Afficher profondeur constatée, nœuds et état de la recherche.
- Filtres : évaluations, rang initial, captures/échecs (information, non sélection automatique de qualité).

## Affichage des scores

- Valeur par défaut **point de vue des Blancs** : positif favorable aux Blancs, négatif favorable aux Noirs ; option « point de vue du camp au trait » avec légende très visible.
- Mate : `M+N`, `M-N` selon convention clairement décrite, jamais converti en `+999.99` centipions comme donnée brute.
- Évaluations et rangs peuvent varier ; utiliser `≈` ou badge « provisoire » pour les analyses incomplètes.
- Distinction obligatoire entre `depth` de la recherche et longueur de PV ; raccourcir l'affichage ne change pas la profondeur calculée.

## Navigation / état global

- La position actuellement affichée peut différer de la racine de l'exercice : afficher les deux repères.
- Les changements de position invalident le panneau contextuel ancien, sauf historique explicitement choisi.
- Confirmer abandon d'une séance avec saisie non enregistrée.
- Aucune animation longue imposée : l'UI est un outil de travail, pas un jeu d'arcade.

## Accessibilité / qualité

- Navigation au clavier, labels d'évaluation, contrastes AA sur les éléments principaux.
- Élément actif visible ; lecteur d'écran : coup SAN et profondeur explicités.
- États vide, chargement, erreur, coup illégal, panne moteur, entrée PGN partielle, absence de calcul jusqu'à 21.
- Ne jamais afficher des chaînes PGN/commentaires comme HTML brut (XSS).
