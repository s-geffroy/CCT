# 19 — Installation Windows à double-clic : contrat opérateur et implémentation

**Objectif :** l'utilisateur Windows télécharge une GitHub Release, extrait l'archive puis **double-clique `INSTALLER.cmd`**. Aucune commande Git, Python, Node ou compilateur requise sur Windows.

**Limite assumée :** « installer d'un clic » désigne le lancement du *bundle extrait* par double-clic. Un `.zip` ouvert dans l'Explorateur Windows n'est pas un installeur. La **première installation de Docker Desktop / WSL 2 peut nécessiter un téléchargement officiel, une activation système, des droits administrateur, un redémarrage ou l'acceptation d'une licence**. Le script ne dissimule ni ne contourne ces étapes.

## Expérience utilisateur cible

1. Ouvrir `https://github.com/OWNER/REPO/releases` depuis le dépôt GitHub public (remplacer par vrai chemin).
2. Télécharger `ChessCalculationTrainer-Windows-vX.Y.Z.zip` et le fichier `.sha256` joint.
3. Dans l'Explorateur Windows, clic droit sur le ZIP > **Extraire tout**. Ne pas lancer des scripts directement à l'intérieur du ZIP compressé.
4. Vérifier la provenance, facultativement le SHA256 selon procédure ci-dessous, puis **double-cliquer `INSTALLER.cmd`** dans le dossier extrait.
5. Une console affichera les contrôles Windows 11 x64, WSL 2, Docker Desktop, Docker Linux et GHCR. Si Docker Desktop est absent, afficher le lien de l'installateur **officiel** ; une fois Docker Desktop installé et ouvert, relancer le même `INSTALLER.cmd`.
6. Le script installe les fichiers locaux sous `%LOCALAPPDATA%\ChessCalculationTrainer`, tire l'image publique par digest, crée le volume persistant `chess-calculation-trainer-data`, démarre l'application et vérifie `health/ready`.
7. Si tout est prêt : navigateur ouvert sur `http://127.0.0.1:8765` et éventuellement raccourci bureau **Chess Calculation Trainer** (créé dans le profil utilisateur).
8. Plus tard : double-cliquer le raccourci ou `OUVRIR.cmd`, et `ARRETER.cmd` pour arrêter le moteur sans effacer les données.

Les scripts modèles dans `templates/windows/` ne sont pas une application à eux seuls. Ils deviennent installables une fois intégrés dans un dépôt **contenant une image publiée, un véritable backend/frontend et un manifeste de release réel**.

## Quels fichiers dans la release Windows ?

```text
ChessCalculationTrainer-Windows-vX.Y.Z.zip
├── INSTALLER.cmd                    # double-clic : installe ou vérifie
├── OUVRIR.cmd                       # double-clic : démarre et ouvre l'interface
├── ARRETER.cmd                      # double-clic : arrête sans effacer les données
├── README_WINDOWS.md
├── compose.yaml
├── release-manifest.json            # digest OCI réel
├── LICENSE
├── THIRD_PARTY_NOTICES.md
└── scripts/windows/
    ├── verify.ps1
    ├── install.ps1
    ├── start.ps1
    ├── stop.ps1
    ├── update.ps1                   # à implémenter avec backup/rollback avant release
    ├── backup.ps1                   # à implémenter avec backup SQLite cohérent
    └── uninstall.ps1                # à implémenter sans effacer volume par défaut
```

**Contrat de chemin :** les `.cmd` sont à la racine ; `.ps1` sous `scripts/windows/`. Dans le dépôt source, les `.cmd`, `.ps1` et le README se trouvent dans `packaging/windows/` (les scripts `.ps1` peuvent y être à plat, puis la CI les réorganise dans le ZIP). La CI copie `compose.yaml` depuis la racine. Les modèles fournis suivent cette convention.

## Pourquoi `.cmd` et non double-clic sur `.ps1` ?

Windows n'exécute pas nécessairement un script `.ps1` au double-clic, selon associations de fichiers et politiques locales. Un petit **lanceur `.cmd`** est plus prédictible : il ouvre PowerShell, affiche les diagnostics, conserve la fenêtre ouverte en cas d'erreur et transmet un code de sortie. Le processus lance `-ExecutionPolicy Bypass` **uniquement pour sa propre instance PowerShell**, sans changer `LocalMachine`/`CurrentUser`. Cette concession UX est explicite, visible dans le fichier et n'a pas vocation à outrepasser une politique d'entreprise imposée par GPO. Ne jamais conseiller de désactiver SmartScreen, Defender ou une politique de sécurité de domaine.

Un `.cmd` téléchargé peut être averti/bloqué par Windows SmartScreen/Smart App Control ; documenter l'éditeur et la provenance, ne pas apprendre à désactiver les protections. Pour un déploiement grand public plus intégré, un `.exe` signé et/ou MSIX peut être ajouté à une version ultérieure, **en parallèle du bundle portable**, sans être considéré comme livrable V1.

## Vérification de l'archive téléchargée

Avant l'extraction ou le double-clic, dans PowerShell (si souhaité) :

```powershell
Get-FileHash -Algorithm SHA256 ".\ChessCalculationTrainer-Windows-v0.1.0.zip"
Get-Content ".\ChessCalculationTrainer-Windows-v0.1.0.zip.sha256"
```

Comparer les 64 caractères hexadécimaux. Si l'empreinte diffère, **ne pas lancer** l'installateur. Le fichier checksum depuis la même Release contribue à détecter une altération accidentelle ; une signature/attestation provenant d'une source indépendante serait une garantie supérieure contre une compromission du compte de publication.

## Docker Desktop : première installation

- Installer depuis <https://docs.docker.com/desktop/setup/install/windows-install/> et activer les prérequis WSL 2 si nécessaire.
- La variante *per-user* est recommandée par Docker Desktop sur la plupart des postes ; activer WSL 2 peut nécessiter des droits élevés et un redémarrage.
- Démarrer Docker Desktop **manuellement**, accepter les conditions, sélectionner moteur de conteneurs Linux. Il peut être arrêté au premier lancement.
- Relancer `INSTALLER.cmd` après que `docker info --format '{{.OSType}}'` retourne `linux`.
- La licence Docker Desktop dépend du contexte d'usage ; lire les conditions de Docker. Il ne faut jamais redistribuer un installateur Docker Desktop bricolé ni accepter sa licence à la place de l'utilisateur.

## Contrat de comportement détaillé

| Propriété | Exigence |
|---|---|
| Installation locale | Répertoire stable `%LOCALAPPDATA%\ChessCalculationTrainer`, pas le dossier Downloads |
| Réexécution | Idempotente pour une même version/digest |
| Mise à jour | Ne jamais remplacer silencieusement un digest différent ; utiliser `update.ps1` après sauvegarde |
| Image | `ghcr.io/owner/repo@sha256:<64-hex>` exacte ; aucune utilisation d'image mutable `latest` |
| Réseau | Bind `127.0.0.1:8765` uniquement ; aucun port écouté sur tout le LAN |
| Données | Volume Docker nommé dédié et préservé par arrêt/réinstallation |
| Docker absent | Explication + page officielle ; abandon propre sans demi-installation |
| Ports en conflit | Erreur lisible, port configurable ; aucune fermeture forcée d'un service tiers |
| Conteneur en échec | Afficher les logs pertinents et l'URL de dépannage ; ne pas annoncer réussite |
| Raccourci bureau | Création facultative, ne pas nécessiter les droits admin |
| Suppression | Par défaut, stop/down **sans `-v`** ; destruction des données sur double confirmation |
| Windows ARM / autre OS | Message de non-support V1 au lieu d'un build émulation automatique |

## Cas à tester sur un VRAI poste Windows 11 x64

1. Docker Desktop + WSL 2 déjà opérationnels : double-clic et navigateur.
2. Docker Desktop absent : message, lien officiel, pas de suppression/modification système inappropriée.
3. Docker installé mais **non démarré** : message explicite.
4. Docker en mode Windows containers : erreur expliquant le passage en conteneurs Linux.
5. GHCR privé : pull refusé, aide vers visibilité du package ; pas de demande de mot de passe à un utilisateur public.
6. Dossier et nom de compte avec espaces/caractères accentués.
7. Réinstallation même version ; conservation du volume et de l'ancienne configuration.
8. Nouvelle version lancée via `INSTALLER.cmd` alors qu'une version existe : refus et renvoi vers `update.ps1`.
9. Port occupé ; délai de démarrage dépassé ; disque insuffisant ; réseau coupé.
10. Desktop shortcut créé et utilisé ; arrêt sans perte des exercices.

**Ne pas prétendre ces scénarios testés parce qu'une CI Ubuntu est verte.** Une CI Windows peut vérifier syntaxe/Pester, mais pas la virtualisation et Docker Desktop d'un poste réel.

## Sources

- <https://docs.docker.com/desktop/setup/install/windows-install/>
- <https://docs.docker.com/desktop/features/wsl/>
- <https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.security/set-executionpolicy>
- <https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository>
