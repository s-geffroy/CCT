# 15 — Sources vérifiées (consultation du 26 octobre 2026)

Les informations de version, compatibilité et droits changent : les liens ci-dessous constituent un **point de départ vérifié**, et non une autorisation de figer des versions sans contrôle au moment du build.

## UI

1. React Chessboard (MIT, API d'options, fonctionnalités d'éditeur et pièces libres) — <https://github.com/Clariity/react-chessboard>
2. React Chessboard, documentation des options — <https://react-chessboard.vercel.app/?path=/docs/how-to-use-options-api--docs>
3. React Chessboard npm : version 5.12.1 observée le 26/10/2026 — <https://www.npmjs.com/package/react-chessboard>
4. React Arborist (MIT, arbre contrôlé/virtualisé) — <https://github.com/jameskerr/react-arborist>
5. React Arborist npm : version 4.0.1 observée le 26/10/2026 ; peer dependencies DnD — <https://www.npmjs.com/package/react-arborist>
6. shadcn/ui (MIT) — <https://github.com/shadcn-ui/ui>
7. React Flow (MIT, alternative graphique non retenue en V1) — <https://reactflow.dev/>
8. Chessground (GPL-3.0-or-later) — <https://github.com/lichess-org/chessground>
9. Lichess PGN Viewer (GPL, orienté lecture) — <https://github.com/lichess-org/pgn-viewer>
10. cm-chessboard (MIT) — <https://github.com/shaack/cm-chessboard>
11. chess.js (BSD-2-Clause) — <https://github.com/jhlywa/chess.js>

## Échecs et moteur

12. Stockfish versions : **Stockfish 19 stable** sorti le 5 septembre 2026, tag `sf_19` — <https://github.com/official-stockfish/Stockfish/releases>
13. Stockfish — téléchargement officiel et binaires universels — <https://stockfishchess.org/download/>
14. Stockfish — compiler depuis la source — <https://official-stockfish.github.io/docs/stockfish-wiki/Compiling-from-source.html>
15. Stockfish — dépôt, licence et sources — <https://github.com/official-stockfish/Stockfish>
16. `python-chess` — arbres PGN, `GameNode`, variantes, commentaires — <https://python-chess.readthedocs.io/en/latest/pgn.html>
17. `python-chess` — API moteur et analyse — <https://python-chess.readthedocs.io/en/latest/engine.html>

## Distribution

18. Docker Desktop Windows — prérequis, modes utilisateur et WSL 2 — <https://docs.docker.com/desktop/setup/install/windows-install/>
19. Docker Desktop + WSL 2 — <https://docs.docker.com/desktop/features/wsl/>
20. Github Container Registry — <https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry>
21. Docker GitHub Actions CI — <https://docs.docker.com/build/ci/github-actions/>
22. Attestations SBOM/provenance — <https://docs.docker.com/build/ci/github-actions/attestations/>
23. Documentation GitHub Releases — <https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository>

## Constats ayant servi aux décisions

- `react-chessboard` offre une API React adaptée à une UI de saisie et éditeur d'échiquier, sans licence GPL pour ce composant.
- `react-arborist` fournit l'arbre contrôlé, virtualisé et pilotable au clavier ; désactiver le DnD de reparenting échiquéen.
- Chessground est robuste mais GPL, ce qui change potentiellement les obligations d'un front fermé ; le projet sera public, mais aucun avantage majeur justifie son intégration en V1.
- `python-chess` préserve les variantes PGN sous forme d'arbre ; ne pas remplacer par un parseur artisanal.
- Stockfish 19 est une version stable ; une nightly de développement n'est pas adaptée à une release reproductible.
- Docker Desktop/WSL 2 et les licences commerciales Docker peuvent varier : l'application n'installe pas silencieusement Docker et n'en redistribue pas l'exécutable.

## Vérifications à refaire juste avant release

- API exactes des versions npm épinglées, compatibilité React, lockfiles et peer dependencies.
- Source Stockfish `sf_19`, SHA exact de l'archive utilisée, empreinte(s) réseau NNUE et Makefile `ARCH` supporté.
- Notes de licences des dépendances réellement embarquées et fichiers de pièces SVG.
- Conditions Windows 11/WSL2/Docker du moment ; droits GitHub Packages/GHCR et permissions Actions.


## Actualisation distribution — 26/10/2026

24. Réglages Actions d'un dépôt : <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository>
25. Démarrage manuel `workflow_dispatch` : <https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow>
26. Publier des images Docker par Actions : <https://docs.github.com/en/actions/tutorials/publish-packages/publish-docker-images>
27. Visibilité indépendante des paquets GHCR et téléchargement anonyme : <https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility>
28. Docker Desktop Windows, installation par utilisateur : <https://docs.docker.com/desktop/setup/install/windows-install/>
29. Modèles pratiques : `templates/github/` et `templates/windows/` inclus dans cette archive ; **non testés sur GitHub/Windows réels**.
