# 05 — Modèle de domaine, base et contrats internes

## Séparation des trois arbres

1. `imported_pgn_tree` : données d'origine (partie, commentaires, variantes) non modifiées automatiquement.
2. `user_tree` : variantes saisies par le joueur durant une session, versionnée puis figée à soumission.
3. `reference_tree` : construit depuis les analyses moteur, sélectif, enrichissable et porteur de provenance.

Ne jamais réutiliser un identifiant de nœud entre ces arbres. Une vue de comparaison est calculée par **projection**, non par mutation des arbres d'origine.

## Entités SQLite proposées

| Table | Champs majeurs | Contraintes |
|---|---|---|
| `positions` | `id`, `fen`, `source_type`, `source_game_id`, `source_node_id`, `history_json`, `created_at`, `validation_status` | instantané immuable ; contexte connu ou marqué absent |
| `games` | `id`, `headers_json`, `raw_pgn`, `imported_at`, `parse_warnings_json` | préserver l'entrée d'origine |
| `game_nodes` | `id`, `game_id`, `parent_id`, `uci`, `san`, `order_index`, `comments_json`, `nags_json`, `fen` | forêt de variantes légales |
| `sessions` | `id`, `position_id`, `mode`, `state`, `started_at`, `submitted_at`, `revealed_at`, `duration_ms`, `root_side` | transitions contrôlées |
| `user_nodes` | `id`, `session_id`, `parent_id`, `move_uci`, `move_san`, `order_index`, `comment`, `human_assessment`, `created_at` | ajout uniquement si légal depuis parent |
| `attempt_snapshots` | `id`, `session_id`, `snapshot_json`, `submitted_at` | ne jamais modifier après soumission |
| `analysis_jobs` | `id`, `position_id`, `session_id`, `scope`, `priority`, `state`, `settings_json`, `started_at`, `ended_at`, `cancel_requested` | travail sérialisé, récupérable ou marqué interrompu |
| `analysis_lines` | `id`, `job_id`, `root_move_uci`, `pv_uci_json`, `depth`, `seldepth`, `nodes`, `nps`, `score_type`, `score_value`, `is_lowerbound`, `is_upperbound`, `multipv_index`, `is_final` | conserver chaque point stable, dernière version lisible |
| `reference_nodes` | `id`, `position_id`, `parent_id`, `move_uci`, `source_job_id`, `status`, `selection_reason`, `confidence_class`, `order_index` | sélectif, jamais prétendu exhaustif |
| `review_diagnostics` | `id`, `session_id`, `category`, `user_node_id`, `reference_node_id`, `evidence_json`, `verdict`, `explanation`, `certainty` | pas d'affirmation sans preuve |
| `settings` | `key`, `value_json`, `updated_at` | valeurs bornées et validées |
| `schema_migrations` | `version`, `applied_at` | migrations déterministes |

**Arborescence SQLite :** index `(session_id, parent_id, order_index)`, `(position_id, parent_id)`, `(job_id, multipv_index)`, `(state, priority, created_at)` ; contraintes FK ; transactions pour insertion de branche et changements d'état.

## États et transitions

Session : `draft → active → submitted → revealed → reviewed` ; autoriser `active → abandoned`, `submitted → revealed` même si le moteur calcule encore, mais alors débriefing clairement incomplet. `reviewed` signifie que le rapport est affichable avec qualité déclarée, et non que la vérité échiquéenne est établie.

Job : `queued → running → complete_depth | budget_exhausted | cancelled | failed` ; après crash, `running → interrupted` lors du redémarrage. Le même job ne revient pas magiquement à un nœud Stockfish déjà calculé.

Branche : `not_explored | queued | provisional | depth_met | budget_exhausted | failed | pruned_by_policy`. « Non explorée » est distinct de « mauvaise ».

## Types conceptuels

```ts
type Score =
  | { kind: 'cp'; value: number; perspective: 'white'; bound?: 'lower'|'upper'|null }
  | { kind: 'mate'; plies: number; perspective: 'white'; bound?: 'lower'|'upper'|null }
  | { kind: 'unknown' };

type AnalysisLine = {
  rootMoveUci: string;
  pvUci: string[];
  depth: number; selDepth?: number;
  score: Score;
  nodes?: number; timeMs?: number;
  status: 'provisional'|'depth_met'|'budget_exhausted'|'cancelled'|'failed';
  engineVersion: string;
  multipvIndex: number;
};

type PositionSnapshot = {
  fen: string; // FEN normalisée orthodoxe, contexte minimal
  historyUci: string[] | null; // null si source isolée sans historique fiable
  variant: 'standard';
  immutableSnapshotId: string;
};
```

Ne pas utiliser d'entier `centipawns` pour représenter un mat. `Score(kind='unknown')` si aucune évaluation exploitable.

## Identité de position et cache

Créer une empreinte déterministe depuis :

`variant + initial_fen + complete_known_history_uci + final_fen + engine_version + NNUE_checksum + hash_mb + threads + multipv + target_depth + searchmoves + adjudication_policy + analysis_policy_version`.

Attention : `threads` n'est pas la sémantique échiquéenne mais peut influencer les résultats de recherche et la reproductibilité ; l'inclure en métadonnées et dans les clés de cache strictes. En cas d'historique absent, séparer le namespace `history_unknown` pour ne jamais affirmer la répétition.

Optimisation possible : second index de position transpositionnel (FEN complète) pour suggérer des réutilisations, **jamais substituer** sans vérifier le contexte de règles. Requête de cache renvoie son niveau de réutilisabilité et son exactitude (strict / prudent / impossible).

## Référence et preuve

Chaque entrée critique doit conserver `selection_reason`: `top_rank`, `opponent_best_defense`, `score_swing`, `forcing_candidate_verified`, `user_branch_requested`, `human_curated`, etc. Une branche humaine réanalysée reste distinguable d'une branche issue de la présélection initiale.

Chaque diagnostic enregistre les jobs/évaluations qui le justifient ; aucun texte « erreur tactique » sans variation légale montrable en débriefing.

## Export

- Export PGN de l'arbre utilisateur et des variantes commentées, avec réserve sur l'information non représentable dans les NAG/PGN.
- Export JSON versionné des sessions (métadonnées, arbres, évaluations utilisateur et références si révélées).
- Import JSON futur seulement après validation stricte du schéma/version.
