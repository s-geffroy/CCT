# 12 — Sécurité, confidentialité, maintenance et licences

## Modèle de menace

Application locale pour un seul joueur ; aucune authentification cloud. Risques principaux : port Docker involontairement exposé au réseau, site web malveillant effectuant des requêtes contre `localhost`, fuite de solutions durant le calcul mental, entrée PGN volumineuse/malveillante, exécution de scripts de release falsifiés, dépendances compromises, épuisement CPU/RAM.

## Mesures obligatoires

1. Bind hôte `127.0.0.1:8765`, **jamais** `0.0.0.0:8765` par défaut.
2. `TrustedHostMiddleware`/validation Host, rejet d'`Origin` cross-site pour mutations et événements ; cookies si utilisés en `SameSite=Strict`, protection CSRF sur POST/PUT/PATCH/DELETE.
3. Pas de CORS wildcard ; ne pas accepter des tokens serveur transmis par un site externe.
4. Bloquer toutes les réponses moteur avant révélation dans le **service** ; ne pas masquer simplement des objets envoyés au navigateur.
5. Processus conteneur non root, filesystem lecture seule + `/tmp` tmpfs et `/data` volume, pas de socket Docker monté, sans `--privileged`, capabilities minimales.
6. Validation des formats de saisie, limites PGN, arbres, commentaires, budgets, queue, longueur du FEN, fréquence requêtes.
7. Pas de `eval` ni concaténation de commandes shell depuis des données utilisateur. Le chemin Stockfish est fixé dans la configuration ; arguments UCI stricts.
8. Les commentaires PGN et champs utilisateur doivent être échappés au rendu ; aucun HTML riche non nettoyé.
9. Ne pas exécuter automatiquement les contributions de GitHub (`curl | bash` ou `Invoke-Expression` sur contenu distant interdits).
10. Journaliser les erreurs moteur sans données inutilement privées et avec tailles bornées ; télémétrie externe désactivée.

## Licence Stockfish

Stockfish 19 est sous **GPL-3.0-or-later** ; la redistribution d'un exécutable ou d'une image contenant ce binaire implique des obligations de licence et de mise à disposition du code source correspondant. Inclure copie de GPL, notices, versions et méthode explicite de récupération de l'exact code source correspondant (tag + patchset + sources NNUE ou liens conformes) ; documenter les modalités légales adéquates.

Attention : exécuter Stockfish via le protocole UCI **ne suffit pas à trancher automatiquement** si tout le programme doit être GPL ; l'étendue du copyleft d'un assemblage/distribution peut nécessiter une analyse juridique. Par simplicité de projet libre, **GPL-3.0-or-later pour tout code original** est proposée à valider par le titulaire du projet avant la première release, après audit de compatibilité de ses bibliothèques (dont `python-chess`).

`react-chessboard`, `react-arborist`, shadcn/ui, React Flow sont MIT d'après leurs dépôts au 26/10/2026. `chess.js` est BSD-2-Clause. Vérifier chaque licence pour les **versions réellement épinglées**, pièces SVG/thèmes/fonts inclus.

## Distribution de Docker Desktop

**Docker Desktop n'est pas redistribué** par ce dépôt ; l'utilisateur l'installe séparément selon le contrat Docker. Ses conditions d'utilisation commerciale sont distinctes de la licence de l'application. Présenter ses exigences et lien officiel sans les ignorer.

## Nom, marques et droits médias

Le nom « Chess Calculation Trainer » est provisoire ; ne pas prétendre que le nom ou logo sont disponibles. Ne pas reprendre la marque, la mise en page ou les assets Lichess/Chess.com sans licence explicite. Préférer thèmes/pièces libres aux droits vérifiés et notices complètes.

## Maintenance et approvisionnement logiciel

- Versions et checksums figés pour Stockfish/NNUE, dépendances lockfiles.
- Actions GitHub épinglées par SHA pour releases de sécurité si possible.
- SBOM et attestation de provenance OCI optionnelles puis recommandées.
- Réévaluer les CVE lors de releases ; aucune mise à jour automatique opaque de l'image.
- Documenter support de versions Windows/WSL/Docker, changement des dépendances et procédure de backup.

## Règle de protection des données

Données locales par défaut, pas de comptes utilisateurs, pas de stockage externe imposé. L'export et l'effacement doivent être explicites, et l'installateur ne détruit jamais le volume par défaut.
