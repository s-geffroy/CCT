# 07 — Moteur pédagogique : comparaison, diagnostics et prudence

## Objectif

Transformer les traces de calcul restituées par le joueur en observations **vérifiables**, et non établir une note psychométrique ou quantifier un « niveau de visualisation mentale » non observable.

## Trois types de séance

| Mode | Traces capturées | Ce qu'on peut inférer |
|---|---|---|
| B mental, sans saisie | temps, position, autoévaluation, révélation | aucune exactitude objective des variantes mentales |
| B mental, avec saisie facultative | candidats/variantes textuels et notes | exactitude de la **restitution**, pas preuve du processus mental |
| C construction | arbre de coups, commentaires, évaluations du joueur | structure, profondeur, corrections et erreurs observables |

## Algorithme de comparaison : quatre étapes

1. **Normaliser l'arbre utilisateur.** Parcourir depuis la position racine, reconvertir chaque coup SAN en UCI dans son contexte, valider et conserver la chaîne de parents. Ne jamais modifier les données de l'utilisateur.
2. **Aligner les branches.** Rapprocher par chemins UCI à partir de la racine ; détecter les transpositions (positions équivalentes sous contexte d'historique adéquat) comme correspondances alternatives **annotées**, non comme fusions.
3. **Compléter la preuve.** Une branche absente de la référence est `not_evaluated` jusqu'à analyse ciblée. Obtenir pour les décisions critiques une recherche de vérification à profondeur/effort documentés. Les PV peuvent diverger à profondeur identique ; inconnu ≠ erreur.
4. **Produire des diagnostics détaillés.** Comparer les coups candidats, défenses adverses, légalité, horizon restitué et estimation de valeur ; mentionner les limites et justifier par une suite UCI légale.

## Taxonomie recommandée

| Catégorie | Définition opérationnelle | Prudence |
|---|---|---|
| `candidate_found` | premier coup envisagé présent dans ensemble référence qualifié | pas suffisant pour « calcul correct » |
| `candidate_omitted` | candidat prioritaire absent de la restitution | ne pas le qualifier de faute sans importance vérifiée |
| `critical_defense_omitted` | défense à effet échiquéen significatif sous vérification | dépend de la référence et du budget |
| `illegal_continuation` | coup illégal à ce nœud | certain si histoire et règles connues |
| `evaluation_mismatch` | appréciation utilisateur incompatible avec une référence robuste | évaluation humaine qualitative, seuils à calibrer |
| `acceptable_alternative` | ligne différente et sans perte critique mise en évidence | jamais punir pour ne pas suivre le 1er choix Stockfish |
| `tactical_refutation` | réfutation concrète et vérifiée contre une ligne saisie | fournir PV et position de bascule |
| `unverified` | manque de budget/de profondeur/d'historique | aucun verdict définitif |
| `no_trace` | séance mentale sans restitution vérifiable | autoévaluation seulement |

## Importance et sévérité

Ne pas déclencher des verdicts fixes uniquement sur une différence de 20, 50 ou 100 centipions : les centipions peuvent être sensibles à la structure, la phase de jeu et le moteur. Pour un diagnostic d'impact, refaire au besoin une analyse ciblée du coup utilisateur et d'alternatives à budget comparable ; conserver l'intervalle de recherche, les bornes et une classe qualitative prudente.

**Hiérarchie** : validité du coup > existence d'une réfutation concrète > différence d'évaluation robuste > divergence de PV seulement. S'il manque des données, diagnostiquer « non déterminé ».

## Rapport utilisateur

Produire des dimensions séparées :

- **Couverture des candidats pertinents :** `found / known_relevant` si ensemble connu et qualifié.
- **Anticipation adverse :** défenses critiques trouvées, manquées, non vérifiées.
- **Exactitude des lignes saisies :** taux de coups légaux et de lignes sans réfutation démontrée.
- **Horizon restitué :** max/median des demi-coups saisis, sans inférence de visualisation cognitive.
- **Évaluation humaine :** concordance qualitative avec référence robuste ; verdict incertain si insuffisance.
- **Évolution personnelle :** comparaison entre séances sur exercices différents, sans classement mondial ni score de QI.

## Prévention du bachotage

Le système peut stocker les exercices déjà vus et leur date de première révélation. Les révisions répétées peuvent être utiles mais **ne pas** confondre apprentissage des solutions et amélioration généralisée. L'efficacité réelle exigerait un protocole contrôlé sur positions inédites ; hors preuve V1.

## Exemples de verdicts sûrs

- « Vous avez envisagé `Cf3` et `e4`, mais pas la défense `...Fxf2+`, vérifiée dans l'analyse ciblée (profondeur 21). »
- « Votre ligne diverge de la première proposition de Stockfish, mais aucune perte déterminante n'a été établie au budget calculé. »
- « Variante non vérifiée : recherche interrompue à profondeur 15, aucune conclusion définitive. »
- « Séance mentale sans transcription : seule votre autoévaluation est disponible. »

## Jeux de données d'évaluation

Construire un corpus de 20 positions minimum, annotées manuellement avec réponses et thèmes (calcul forcé, défense, coup calme, finale, choix multiples) et quelques positions volontairement ambiguës. Chaque verdict a un test de non-régression. Conserver les versions des annotations.
