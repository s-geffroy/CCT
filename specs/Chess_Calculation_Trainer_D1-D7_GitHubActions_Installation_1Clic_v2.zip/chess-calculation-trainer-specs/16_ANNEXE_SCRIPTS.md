# 16 — Scripts de référence à transformer en fichiers réels par le LLM

**Statut :** exemples concrets de contrat d'installation et de packaging. Ces scripts ne sont **pas exécutables directement depuis ce ZIP**, puisque tous les livrables remis ici sont volontairement des fichiers `.md`. Le LLM doit extraire, adapter et tester leur contenu dans les vrais `packaging/windows/*.ps1` du dépôt applicatif, avec le `compose.yaml` et les images de sa release. Ne pas prétendre qu'une installation Windows a déjà été testée.

## 1. Manifeste d'une GitHub Release

Chemin produit par CI : `release-manifest.json` (exemple **à générer** à partir du digest OCI exact).

```json
{
  "schema_version": 1,
  "app_version": "v1.0.0",
  "target_platform": "linux/amd64",
  "windows_target": "Windows 11 x64, Docker Desktop, WSL 2",
  "image_ref": "ghcr.io/OWNER/REPOSITORY@sha256:REPLACE_WITH_64_HEX_DIGEST",
  "host_port_default": 8765
}
```

La valeur `REPLACE_WITH_64_HEX_DIGEST` n'est **pas** utilisable. Elle doit être remplacée par le vrai `sha256` de l'image après push. Ne jamais fabriquer un digest fictif dans une release.

## 2. Exemple complet : `verify.ps1`

Emplacement dans la release : `scripts/windows/verify.ps1`.

```powershell
#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Require-Command([string]$Name, [string]$Message) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw $Message
    }
}

try {
    if ($env:OS -ne 'Windows_NT') {
        throw 'Cet installateur cible Windows 11 x64.'
    }
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $build = [int]$os.BuildNumber
    if ($build -lt 22000) {
        throw ('Windows 11 requis pour le support V1. Build détecté : ' + $build)
    }
    if ($env:PROCESSOR_ARCHITECTURE -notin @('AMD64', 'ARM64')) {
        throw 'Architecture Windows non reconnue.'
    }
    # Ne pas confondre un processus PowerShell x86 sur OS x64 avec CPU ARM.
    $cpuArch = (Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1).Architecture
    if ($cpuArch -ne 9) {
        throw 'Seul Windows x64 / processeur AMD64 est supporté en V1 (pas Windows ARM).'
    }
    Require-Command 'wsl.exe' 'WSL 2 absent. Suivez la documentation Microsoft/Docker.'
    $wslVersion = & wsl.exe --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw 'WSL non opérationnel ou trop ancien. Installer/mettre à jour WSL 2 puis redémarrer si nécessaire.'
    }
    Require-Command 'docker' 'Docker Desktop absent. Installer depuis https://docs.docker.com/desktop/setup/install/windows-install/'
    & docker compose version | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Docker Compose v2 indisponible.' }
    $ostype = (& docker info --format '{{.OSType}}' 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $ostype -ne 'linux') {
        throw 'Docker Desktop doit être démarré avec un moteur Linux (WSL 2).'
    }
    Write-Host 'Pré-requis principaux vérifiés : Windows 11 x64, WSL, Docker Linux et Compose.'
    Write-Host 'Vérifications complémentaires requises par install.ps1 : disque, port, image et healthcheck.'
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
```

**Validation supplémentaire de l'implémenteur :** détecter `wsl --list --verbose` pour distinguer activation WSL 2 et installation des distributions, vérifier RAM/disque, et signaler si le backend Docker VMM était activé au lieu du profil WSL 2 retenu. `wsl.exe --version` n'est pas une preuve suffisante que WSL 2 fonctionne effectivement ; la vérification finale `docker info` Linux est nécessaire. Le `Win32_Processor.Architecture=9` correspond aux processeurs x64. Les environnements Windows multi-architectures exigent des tests dédiés.

## 3. Exemple complet : `install.ps1`

Préconditions : dossier extrait contenant `compose.yaml`, `release-manifest.json`, sous-dossier `scripts/windows`. Ce script suppose un manifeste réel, un volume persistant et des fichiers correctement produits par la release CI.

```powershell
#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$composePath = Join-Path $root 'compose.yaml'
$manifestPath = Join-Path $root 'release-manifest.json'
$envPath = Join-Path $root '.env'
$verifyPath = Join-Path $PSScriptRoot 'verify.ps1'

try {
    & $verifyPath
    if ($LASTEXITCODE -ne 0) { throw 'Vérification des prérequis échouée.' }
    if (-not (Test-Path -LiteralPath $composePath)) { throw 'compose.yaml absent du bundle.' }
    if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'release-manifest.json absent du bundle.' }

    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.target_platform -ne 'linux/amd64') {
        throw 'Le manifeste ne cible pas linux/amd64.'
    }
    $ref = [string]$manifest.image_ref
    if ($ref -notmatch '^ghcr\.io/[a-z0-9_.-]+/[a-z0-9_.-]+@sha256:[a-f0-9]{64}$') {
        throw 'Référence image GHCR/digest invalide dans le manifeste de release.'
    }

    if (-not (Test-Path -LiteralPath $envPath)) {
        $content = @(
            ('IMAGE_REF=' + $ref)
            'HOST_PORT=8765'
            'APP_CPUS=2.0'
            'APP_MEMORY=2g'
        ) -join "`n"
        [System.IO.File]::WriteAllText($envPath, $content + "`n", (New-Object System.Text.UTF8Encoding($false)))
    } else {
        Write-Host '.env existant conservé (installation idempotente).'
    }

    Push-Location $root
    try {
        & docker compose --project-directory $root --env-file $envPath -f $composePath config --quiet
        if ($LASTEXITCODE -ne 0) { throw 'Validation Docker Compose échouée.' }
        & docker compose --project-directory $root --env-file $envPath -f $composePath pull
        if ($LASTEXITCODE -ne 0) { throw 'Téléchargement de l’image échoué.' }
        & docker compose --project-directory $root --env-file $envPath -f $composePath up -d
        if ($LASTEXITCODE -ne 0) { throw 'Démarrage du conteneur échoué.' }
    } finally {
        Pop-Location
    }

    $settings = Get-Content -LiteralPath $envPath -Encoding UTF8
    $portMatch = $settings | Where-Object { $_ -match '^HOST_PORT=([0-9]+)$' } | Select-Object -Last 1
    if (-not $portMatch) { throw 'HOST_PORT absent ou incorrect dans .env.' }
    $port = [int](($portMatch -split '=')[1])
    if ($port -lt 1 -or $port -gt 65535) { throw 'Port local invalide.' }
    $url = 'http://127.0.0.1:' + $port + '/api/v1/health/ready'
    $ready = $false
    for ($i = 0; $i -lt 60; $i++) {
        try {
            $r = Invoke-WebRequest -Uri $url -TimeoutSec 4 -UseBasicParsing
            if ($r.StatusCode -eq 200) { $ready = $true; break }
        } catch { Start-Sleep -Seconds 2 }
    }
    if (-not $ready) {
        throw 'Le conteneur a démarré mais health/ready ne répond pas : consulter docker compose logs app.'
    }
    Start-Process ('http://127.0.0.1:' + $port)
    Write-Host ('Application prête : http://127.0.0.1:' + $port)
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
```

**Points à améliorer/tester par le LLM avant release :** vérifier l'identité de l'image retenue par `.env` existant (une installation déjà présente ne doit pas installer silencieusement un digest obsolète ou incompatible avec le nouveau bundle), tester le port occupé avant `up`, tester cache disque et droits, vérifier effectivement la compatibilité Docker Compose `config --quiet` sur version minimale, gérer le cas image démarrée mais healthcheck en état KO et produire des logs de diagnostic.

## 4. Exemple : `start.ps1` et `stop.ps1`

```powershell
# start.ps1 : structure à extraire et tester
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$envPath = Join-Path $root '.env'
$composePath = Join-Path $root 'compose.yaml'
& docker compose --project-directory $root --env-file $envPath -f $composePath up -d
if ($LASTEXITCODE -ne 0) { throw 'Démarrage impossible.' }

# stop.ps1 : dans un FICHIER SÉPARÉ, mêmes 3 variables de chemin
& docker compose --project-directory $root --env-file $envPath -f $composePath stop
if ($LASTEXITCODE -ne 0) { throw 'Arrêt impossible.' }
```

Implémenter `backup.ps1` via **API ou `sqlite3.backup()`** exécuté dans le conteneur, pas une copie brute de `app.sqlite` en cours d'utilisation. `update.ps1` doit télécharger/prendre un bundle de release récent et **explicitement** refaire `backup`, contrôler la migration et recommander rollback si échec ; `uninstall.ps1` doit préserver le volume par défaut et requérir confirmation renforcée pour une suppression volontaire.

## 5. Exemple : script Linux d'aide au développement

```bash
#!/usr/bin/env bash
set -euo pipefail

docker compose -f compose.dev.yaml build
docker compose -f compose.dev.yaml up -d
# Le LLM doit utiliser les healthchecks du vrai Compose et exécuter les tests.
```

## 6. Checklist script de release GitHub Actions

Le LLM crée un workflow YAML réel qui :

```text
on push tag v*:
  -> test Ubuntu (backend/frontend/E2E)
  -> build OCI linux/amd64, push ghcr.io/${owner}/${repo}:vX.Y.Z
  -> lire digest SHA256 résultant du push (sortie build-push-action)
  -> générer release-manifest.json avec ghcr.io/owner/repo@sha256:...
  -> copier scripts Windows, compose.yaml, notices, README_WINDOWS
  -> zipper le bundle et calculer SHA256 sur ZIP terminé
  -> publier GitHub Release et attestation si disponible
  -> tester téléchargement public et image GHCR lisible sans auth
```

La génération du manifeste est faite **après** le push OCI, jamais avant. Protéger le token GitHub par permissions minimales ; utiliser `github.ref_name`, pas une version hardcodée. Les commandes GitHub Actions finales doivent être réellement exécutées sur le dépôt public après les autorisations nécessaires.

## 7. Commandes utilisateur Windows à documenter

```powershell
# Après vérification de la Release GitHub et extraction du ZIP
.\scripts\windows\verify.ps1
.\scripts\windows\install.ps1

# Ensuite :
.\scripts\windows\stop.ps1
.\scripts\windows\start.ps1
```

Ne jamais conseiller `Set-ExecutionPolicy Unrestricted` au niveau machine. Si Windows marque le fichier téléchargé comme bloqué, documenter la décision utilisateur après vérification de provenance : `Unblock-File -Path .\scripts\windows\install.ps1` et fichiers nécessaires, **sans masquer les avertissements**.
