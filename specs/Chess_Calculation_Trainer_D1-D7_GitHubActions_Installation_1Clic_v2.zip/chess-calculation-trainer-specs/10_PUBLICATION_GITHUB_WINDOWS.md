# 10 — Publication GitHub → installation Windows sans chaîne de compilation

> **Mise à jour D1–D7 du 26 octobre 2026 :** parcours utilisateur principal par **double-clic sur `INSTALLER.cmd`**, après extraction du ZIP GitHub Release. Voir `18_ACTIVER_GITHUB_ACTIONS_ET_GHCR.md`, `19_INSTALLATION_WINDOWS_DOUBLE_CLIC.md` et `20_TEMPLATES_CI_INSTALLATION_ET_CRITERES.md`. Les commandes PowerShell directes ci-dessous restent un chemin alternatif pour utilisateurs avancés.

## Principe de distribution arrêté

**Le LLM développe et construit sous Linux**. Le PC Windows **ne compile rien** : il récupère une *GitHub Release* contenant un bundle Windows en ZIP, lequel pointe vers une image OCI publique `linux/amd64` publiée sur GitHub Container Registry (**GHCR**). L'installateur télécharge cette image avec Docker Desktop puis la démarre.

Ce découplage est impératif : pas de Python, Node, GCC, Git ou WSL Ubuntu manuel à installer par notre application sur la machine cible. Docker Desktop avec backend WSL 2 est un prérequis vérifié, avec procédure d'aide claire si absent.

## Produits exacts d'une release `vX.Y.Z`

1. Dépôt GitHub public source (tag immuable `vX.Y.Z`).
2. Image GHCR publique `ghcr.io/<owner>/<repo>:vX.Y.Z` + **digest OCI**. Construite/testée pour `linux/amd64`.
3. Archive `ChessCalculationTrainer-Windows-vX.Y.Z.zip` contenant :
   - **`INSTALLER.cmd`, `OUVRIR.cmd`, `ARRETER.cmd` à la racine pour les doubles-clics**,
   - `compose.yaml` (référence image via `IMAGE_REF` dans `.env`),
   - `.env.template` ou `.env` créé à l'installation,
   - `release-manifest.json` avec version, image référence **digest**, hash ZIP et compatibilité (le manifeste ne peut contenir le SHA du ZIP dont il fait partie ; publier SHA à côté),
   - `scripts/windows/install.ps1`, `start.ps1`, `stop.ps1`, `update.ps1`, `backup.ps1`, `uninstall.ps1`, `verify.ps1`,
   - `README_WINDOWS.md`, `LICENSE`, `THIRD_PARTY_NOTICES.md`.
4. `ChessCalculationTrainer-Windows-vX.Y.Z.zip.sha256` public à côté du ZIP, calculé **après** l'archive, et notes de versions.
5. Optionnel : attestation provenance/SBOM de l'image.

## CI/CD GitHub Actions

### Sur Pull Request

- Ubuntu : installation lockfiles, lint, types, tests backend/frontend, tests de modèle, tests de moteur avec Stockfish téléchargé/compilé en mode figé, build image, test `docker run` et smoke `localhost`.
- Ubuntu : E2E navigateur (Playwright) sur application démarrée.
- Windows runner : PSScriptAnalyzer, analyse statique des `.ps1`, tests Pester de fonctions mockées (ne pas prétendre simuler Docker Desktop réel).
- Analyse licences et dépendances (SCAs) ; secrets pas nécessaires pour tests simples.

### Sur tag versionné

1. Rejouer tests (ne pas publier sur commit non testé).
2. Build/push GHCR, versionnée, OCI digest capturé comme sortie ; permissions `packages: write` et `contents: read`, `GITHUB_TOKEN` limité.
3. Publier manifest de release avec digest **réel** et version ; ne jamais laisser `:latest` dans les fichiers destinés aux utilisateurs.
4. Fabriquer archive Windows avec manifeste, scripts et `compose.yaml` de la même révision.
5. Publier Release GitHub et fichier `.sha256` ; description des migrations/risques.
6. Vérifier publiquement que l'image est en lecture anonyme ; un utilisateur Windows ne doit pas avoir besoin de `docker login`.

### Politique d'immuabilité

- L'installation doit être **répétable** : le manifeste doit contenir une référence `ghcr.io/...@sha256:...`, pas un tag mutable seul.
- `update.ps1` télécharge un **nouveau bundle de version**, effectue sauvegarde et vérification, applique la nouvelle image **par digest**, puis exécute migrations et healthcheck ; procédure de retour arrière documentée.
- `latest` peut être publié à titre indicatif, mais jamais utilisé par défaut par un script de release.

## Installation Windows : flux attendu

1. L'utilisateur ouvre la page Releases du projet public et télécharge l'archive Windows + checksum, en vérifiant le `sha256` selon instructions.
2. Il extrait dans un dossier accessible, par exemple `%LOCALAPPDATA%\ChessCalculationTrainer\app` (ou un dossier qu'il choisit).
3. Il ouvre PowerShell **sans privilèges administrateur par défaut**, lit `README_WINDOWS.md`, lance :

```powershell
.\scripts\windows\verify.ps1
.\scripts\windows\install.ps1
```

4. Le script vérifie architecture x64, Windows pris en charge, `wsl --version`, virtualisation, Docker Desktop, `docker info` Linux, `docker compose version`, disque/RAM, accès registry et port local.
5. Si Docker Desktop ou WSL manque, afficher le lien officiel et les commandes à exécuter **avec consentement explicite**. Ne pas lancer d'installation opaque, ni tenter d'obtenir l'élévation silencieusement.
6. Il vérifie l'empreinte OCI attendue, crée `.env` sans écraser une configuration existante, vérifie le volume persistent, `docker compose pull`, `docker compose up -d` puis healthcheck.
7. Si état prêt, ouvre `http://127.0.0.1:8765` dans le navigateur par défaut.
8. Réinstallation idempotente ; `stop.ps1` stoppe sans détruire les données.

## Exigences PowerShell

- Compatible PowerShell 5.1 **et** 7 si possible ; tester 5.1 sur Windows runner.
- `Set-StrictMode -Version Latest`, `$ErrorActionPreference='Stop'`, chaînes UTF-8 correctement encodées, chemins avec espaces/accents.
- Aucun `Invoke-Expression` à partir du réseau, ni `curl | iex`, ni contournement silencieux de l'ExecutionPolicy ; éventuellement documenter `Unblock-File` après vérification provenance et SHA.
- Les scripts ne doivent pas écrire dans `Program Files` ou modifier le PATH global sans consentement.
- `-WhatIf` / `-Confirm` pour opérations de sauvegarde/désinstallation si faisable ; désinstallation préserve les données par défaut.
- S'assurer que les scripts ne modifient pas d'autres projets Docker et utilisent `docker compose -p chess-calculation-trainer -f ...` uniquement.

## `compose.yaml` attendu (spécification)

```yaml
name: chess-calculation-trainer
services:
  app:
    image: ${IMAGE_REF:?IMAGE_REF doit etre defini dans .env}
    ports:
      - "127.0.0.1:${HOST_PORT:-8765}:8000"
    volumes:
      - trainer_data:/data
    environment:
      APP_DATA_DIR: /data
      APP_MODE: production
    cpus: ${APP_CPUS:-2.0}
    mem_limit: ${APP_MEMORY:-2g}
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8000/api/v1/health/ready', timeout=2)"]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 30s
    security_opt:
      - no-new-privileges:true
    read_only: true
    tmpfs:
      - /tmp
volumes:
  trainer_data:
    name: chess-calculation-trainer-data
```

Ce fragment est une **cible** : l'implémenteur doit le tester réellement, y compris avec SQLite en volume, architecture image, permissions `/data`, limites cgroups et bibliothèques NNUE ; adapter `cpus` et `mem_limit` selon configuration hôte. Vérifier que le runtime fonctionne avec `read_only: true` (caches Python, tmp, lib, migrations).

## Sauvegarde et rollback

- SQLite : utiliser backup cohérent via API/base SQLite ou séquence contrôlée après arrêt, **jamais** copier directement un `app.sqlite` ouvert en WAL sans ses journaux.
- `backup.ps1` produit une archive horodatée des données exportées ou utilise un conteneur temporaire et la méthode SQLite backup ; vérifier que l'archive contient une base restaurable.
- `uninstall.ps1` effectue `docker compose down` (sans `-v`) puis annonce où se trouve le volume. Supprimer le volume **uniquement** via option explicite de destruction, avec double confirmation.
- `update.ps1` sauvegarde, télécharge/pointe vers digest cible et vérifie healthcheck. Si incompatible, afficher procédure de restauration en maintenant anciennes données sauvegardées (rollback applicatif ne garantit pas rollback de schéma sans restore).

## Difficultés réelles à documenter

- Docker Desktop et WSL 2 possèdent des prérequis et conditions de licence indépendants du projet.
- Windows Home est compatible avec conteneurs Linux via WSL 2 lorsque configuration supportée ; **ne pas** exiger Pro uniquement.
- Docker Desktop ne démarre pas toujours juste après installation et peut exiger une acceptation des conditions par l'utilisateur.
- GitHub Actions Linux valide l'image mais **pas** une installation Windows complète ; un test manuel Windows 11 x64 reste un gate de publication.

## Références

- <https://docs.docker.com/desktop/setup/install/windows-install/>
- <https://docs.docker.com/desktop/features/wsl/>
- <https://docs.docker.com/build/ci/github-actions/>
- <https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry>
- <https://docs.docker.com/build/ci/github-actions/attestations/>
