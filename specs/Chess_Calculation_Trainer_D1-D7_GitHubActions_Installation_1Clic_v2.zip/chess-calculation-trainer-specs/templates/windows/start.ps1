#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
try {
    & (Join-Path $PSScriptRoot 'verify.ps1')
    $root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
    $envFile = Join-Path $root '.env'
    $composeFile = Join-Path $root 'compose.yaml'
    if (-not (Test-Path $envFile) -or -not (Test-Path $composeFile)) {
        throw 'Installation introuvable : lancez INSTALLER.cmd depuis une GitHub Release.'
    }
    & docker compose --project-name chess-calculation-trainer --project-directory $root --env-file $envFile -f $composeFile up -d
    if ($LASTEXITCODE -ne 0) { throw 'Impossible de demarrer le conteneur.' }
    $line = @(Get-Content $envFile | Where-Object { $_ -match '^HOST_PORT=' }) | Select-Object -Last 1
    if (-not $line) { throw 'HOST_PORT absent.' }
    $port = [int]($line.Substring(10))
    $url = 'http://127.0.0.1:' + $port
    for ($i=0; $i -lt 60; $i++) {
        try {
            $r = Invoke-WebRequest -Uri ($url + '/api/v1/health/ready') -UseBasicParsing -TimeoutSec 3
            if ($r.StatusCode -eq 200) { Start-Process $url; exit 0 }
        } catch { Start-Sleep -Seconds 2 }
    }
    throw 'Le moteur a demarre mais la sonde de disponibilite ne repond pas.'
} catch { Write-Error $_.Exception.Message; exit 1 }
