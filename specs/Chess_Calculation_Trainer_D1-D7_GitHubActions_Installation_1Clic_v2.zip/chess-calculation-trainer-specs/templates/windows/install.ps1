#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-DockerCompose([string[]] $Arguments) {
    & docker compose --project-name chess-calculation-trainer --project-directory $appRoot --env-file $envFile -f $composePath @Arguments
    if ($LASTEXITCODE -ne 0) { throw ('docker compose a echoue : ' + ($Arguments -join ' ')) }
}

try {
    $sourceRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
    $sourceManifestPath = Join-Path $sourceRoot 'release-manifest.json'
    $sourceComposePath = Join-Path $sourceRoot 'compose.yaml'
    $verify = Join-Path $PSScriptRoot 'verify.ps1'
    foreach ($file in @($sourceManifestPath, $sourceComposePath, $verify)) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Bundle incomplet : ' + $file) }
    }
    & $verify
    $manifest = Get-Content -LiteralPath $sourceManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.target_platform -ne 'linux/amd64') { throw 'Image non compatible : plateforme attendue linux/amd64.' }
    $imageRef = [string]$manifest.image_ref
    if ($imageRef -cnotmatch '^ghcr\.io/[a-z0-9_.-]+/[a-z0-9_.-]+@sha256:[0-9a-f]{64}$') {
        throw 'Reference GHCR invalide : version digest immuable obligatoire.'
    }
    $appRoot = Join-Path $env:LOCALAPPDATA 'ChessCalculationTrainer'
    $envFile = Join-Path $appRoot '.env'
    $composePath = Join-Path $appRoot 'compose.yaml'

    # Do not silently convert an installation into an upgrade.
    if (Test-Path -LiteralPath $envFile -PathType Leaf) {
        $previous = @(Get-Content -LiteralPath $envFile | Where-Object { $_ -match '^IMAGE_REF=' })
        if ($previous.Count -ne 1) { throw 'La configuration existante comporte une reference image ambigue.' }
        if ($previous[0].Substring(10) -cne $imageRef) {
            throw 'Une autre version est installee. Utiliser update.ps1 (sauvegarde et migration), pas INSTALLER.cmd.'
        }
    }

    # A release is copied into a stable app directory, not run from Downloads.
    if (-not (Test-Path -LiteralPath $appRoot)) { New-Item -ItemType Directory -Path $appRoot -Force | Out-Null }
    $scriptsDest = Join-Path $appRoot 'scripts\windows'
    if (-not (Test-Path -LiteralPath $scriptsDest)) { New-Item -ItemType Directory -Path $scriptsDest -Force | Out-Null }
    Copy-Item -LiteralPath $sourceComposePath -Destination $composePath -Force
    Copy-Item -LiteralPath $sourceManifestPath -Destination (Join-Path $appRoot 'release-manifest.json') -Force
    foreach ($name in @('INSTALLER.cmd','OUVRIR.cmd','ARRETER.cmd','README_WINDOWS.md')) {
        $source = Join-Path $sourceRoot $name
        if (-not (Test-Path -LiteralPath $source)) { throw ('Fichier du bundle absent : ' + $name) }
        Copy-Item -LiteralPath $source -Destination (Join-Path $appRoot $name) -Force
    }
    Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'scripts\windows') -Filter '*.ps1' -File |
        Copy-Item -Destination $scriptsDest -Force

    if (-not (Test-Path -LiteralPath $envFile)) {
        $config = @("IMAGE_REF=$imageRef", 'HOST_PORT=8765', 'APP_CPUS=2.0', 'APP_MEMORY=2g') -join "`n"
        [System.IO.File]::WriteAllText($envFile, $config + "`n", (New-Object System.Text.UTF8Encoding($false)))
    }

    $rawPort = @(Get-Content $envFile | Where-Object { $_ -match '^HOST_PORT=' })
    if ($rawPort.Count -ne 1) { throw 'Port HOST_PORT manquant ou ambigu dans .env.' }
    $portString = $rawPort[0].Substring(10)
    $port = 0
    if (-not [int]::TryParse($portString, [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        throw 'HOST_PORT doit etre un nombre entre 1 et 65535.'
    }

    Invoke-DockerCompose -Arguments @('config', '--quiet')
    Invoke-DockerCompose -Arguments @('pull')
    Invoke-DockerCompose -Arguments @('up', '-d')

    $url = 'http://127.0.0.1:' + $port
    $ready = $false
    for ($i = 0; $i -lt 60; $i++) {
        try {
            $response = Invoke-WebRequest -Uri ($url + '/api/v1/health/ready') -TimeoutSec 3 -UseBasicParsing
            if ($response.StatusCode -eq 200) { $ready = $true; break }
        } catch { Start-Sleep -Seconds 2 }
    }
    if (-not $ready) {
        Write-Host 'Logs recents (application non prete) :'
        & docker compose --project-name chess-calculation-trainer --project-directory $appRoot --env-file $envFile -f $composePath logs --tail=40 app
        throw 'Le healthcheck ne repond pas. Aucune reussite annoncee.'
    }

    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        if ($desktop) {
            $linkPath = Join-Path $desktop 'Chess Calculation Trainer.lnk'
            if (-not (Test-Path -LiteralPath $linkPath)) {
                $shell = New-Object -ComObject WScript.Shell
                $shortcut = $shell.CreateShortcut($linkPath)
                $shortcut.TargetPath = (Join-Path $appRoot 'OUVRIR.cmd')
                $shortcut.WorkingDirectory = $appRoot
                $shortcut.Description = 'Ouvrir Chess Calculation Trainer'
                $shortcut.Save()
            }
        }
    } catch { Write-Warning ('Raccourci bureau non cree : ' + $_.Exception.Message) }
    Start-Process $url
    Write-Host ('Application installee et prete : ' + $url)
    Write-Host ('Dossier local : ' + $appRoot)
    Write-Host 'Les donnees sont stockees dans le volume Docker chess-calculation-trainer-data.'
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
