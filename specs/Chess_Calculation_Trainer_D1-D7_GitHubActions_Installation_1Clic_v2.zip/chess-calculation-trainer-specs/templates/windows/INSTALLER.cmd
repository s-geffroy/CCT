@echo off
setlocal
cd /d "%~dp0"
cls
echo ==========================================
echo  Chess Calculation Trainer - Installation
echo ==========================================
echo.
echo Lisez README_WINDOWS.md et verifiez la provenance de cette archive.
echo Cette installation ne modifie pas la politique PowerShell globale.
echo.
if not exist "%~dp0scripts\windows\install.ps1" (
  echo ERREUR : fichiers de release incomplets. Extraire tout le ZIP.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows\install.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo INSTALLATION NON TERMINEE - consulter le message ci-dessus.
if "%RESULT%"=="0" echo Installation terminee.
pause
exit /b %RESULT%
