# Chess Calculation Trainer — Installation Windows 11 x64

**Ceci est le fichier à inclure dans une future GitHub Release, après compilation et publication du vrai logiciel.**

1. Télécharger l'archive ZIP **depuis les Releases du dépôt officiel** et vérifier si possible son `.zip.sha256`.
2. Clic droit sur l'archive > **Extraire tout** ; ne pas exécuter directement depuis le ZIP ouvert.
3. Ouvrir le dossier extrait et **double-cliquer `INSTALLER.cmd`**.
4. Si une condition préalable manque, installer Docker Desktop depuis <https://docs.docker.com/desktop/setup/install/windows-install/> avec WSL 2, démarrer Docker Desktop, accepter ses conditions, puis double-cliquer de nouveau `INSTALLER.cmd`.
5. Une fois le moteur prêt, le navigateur s'ouvre sur <http://127.0.0.1:8765>. Un raccourci bureau peut être créé.
6. Pour redémarrer : `OUVRIR.cmd` ; pour arrêter : `ARRETER.cmd`.

Aucun téléchargement d'exécutable inconnu n'est lancé automatiquement. Le script utilise **uniquement** l'image GHCR publique **épinglée par SHA256 dans `release-manifest.json`**. Le premier démarrage nécessite une connexion Internet pour télécharger l'image ; après installation l'interface reste locale.

Si une politique d'entreprise empêche les scripts `.cmd`/PowerShell, contacter l'administrateur : **ne pas désactiver ces protections**. Ne jamais désinstaller Docker ni supprimer les volumes si d'autres applications en dépendent.

Le projet n'est pas l'éditeur de Docker Desktop. Les conditions d'utilisation de Docker s'appliquent indépendamment.
