#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
try {
    & (Join-Path $PSScriptRoot 'verify.ps1')
    $root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
    $envFile = Join-Path $root '.env'
    $composeFile = Join-Path $root 'compose.yaml'
    if (-not (Test-Path $envFile) -or -not (Test-Path $composeFile)) { throw 'Installation introuvable.' }
    & docker compose --project-name chess-calculation-trainer --project-directory $root --env-file $envFile -f $composeFile stop
    if ($LASTEXITCODE -ne 0) { throw 'Arret du conteneur impossible.' }
    Write-Host 'Application arretee ; volume utilisateur preserve.'
} catch { Write-Error $_.Exception.Message; exit 1 }
