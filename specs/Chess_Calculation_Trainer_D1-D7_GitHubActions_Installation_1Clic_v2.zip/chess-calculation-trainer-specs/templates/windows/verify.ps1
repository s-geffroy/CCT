#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT') { throw 'Windows est requis.' }
$os = Get-CimInstance -ClassName Win32_OperatingSystem
if ([int]$os.BuildNumber -lt 22631) {
    throw ('Windows 11 x64 version 23H2 ou plus recente requise pour la V1. Build = ' + $os.BuildNumber)
}
$arch = (Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1).Architecture
if ($arch -ne 9) { throw 'Windows ARM n est pas pris en charge en V1 ; processeur AMD64 requis.' }
$computer = Get-CimInstance -ClassName Win32_ComputerSystem
if ([int64]$computer.TotalPhysicalMemory -lt 8GB) { throw 'Au moins 8 Go de RAM sont requis pour Docker Desktop.' }
if (-not (Get-Command 'wsl.exe' -ErrorAction SilentlyContinue)) {
    throw 'WSL non detecte. Consulter https://docs.docker.com/desktop/setup/install/windows-install/'
}
& wsl.exe --version | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'WSL trop ancien ou non operationnel. Executer wsl --install ou wsl --update selon les instructions Microsoft.' }
if (-not (Get-Command 'docker.exe' -ErrorAction SilentlyContinue)) {
    # Per-user installs may not yet be reflected in this terminal's PATH.
    $candidatePaths = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\DockerDesktop\resources\bin\docker.exe'),
        (Join-Path $env:ProgramFiles 'Docker\Docker\resources\bin\docker.exe')
    )
    foreach ($candidate in $candidatePaths) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $env:PATH = ([System.IO.Path]::GetDirectoryName($candidate) + ';' + $env:PATH)
            break
        }
    }
}
if (-not (Get-Command 'docker.exe' -ErrorAction SilentlyContinue)) {
    Write-Host 'Docker Desktop non detecte. Installer le produit officiel, le demarrer, puis relancer INSTALLER.cmd.'
    Start-Process 'https://docs.docker.com/desktop/setup/install/windows-install/'
    throw 'Docker Desktop absent : installation de l application non commencee.'
}
& docker compose version | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Docker Compose v2 indisponible.' }
$ostype = (& docker info --format '{{.OSType}}' 2>&1 | Out-String).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop est installe mais son moteur ne repond pas. Demarrez Docker Desktop.' }
if ($ostype -ne 'linux') { throw 'Docker Desktop doit executer des conteneurs Linux (WSL 2), pas Windows containers.' }
$drive = ([System.IO.Path]::GetPathRoot($env:LOCALAPPDATA)).TrimEnd('\')
$disk = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $drive + "'")
if ($null -ne $disk -and [int64]$disk.FreeSpace -lt 5GB) { throw 'Espace disque libre insuffisant (<5 Go).' }
Write-Host 'Pre-requis verifies : Windows 11 x64, WSL 2, Docker Desktop Linux, Compose, ressources.'
