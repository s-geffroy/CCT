@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows\stop.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" echo Application arretee, donnees conservees.
pause
exit /b %RESULT%
