# 11 — Stratégie de tests et critères d'acceptation

## Barrières de livraison

Aucune V1 publique sans tests vert **et** revue réelle d'installation Windows. Séparer `unit`, `integration`, `e2e`, `engine`, `distribution` et `manual_windows`. Les tests moteurs longs doivent être isolés des tests unitaires rapides.

## Matrice technique (acceptation observable)

| ID | Scénario | Critère de passage |
|---|---|---|
| T01 | Windows 11 x64 + WSL2 + Docker Desktop | `install.ps1` lance image GHCR sans Python/Node/Git locaux ; UI accessible |
| T02 | relancer `install.ps1` | ni pertes ni doublons ni écrasement configuration |
| T03 | import FEN | pièces/trait/roque/EP exacts, validation erreurs |
| T04 | import PGN avec plusieurs branches/commentaires | arbre et historique conservés, erreurs remontées |
| T05 | éditeur de position | légalités, promotion, EP, droits au roque testés |
| T06 | position invalide | moteur jamais appelé ; raison lisible |
| T07 | position ayant <20 coups | exactement `min(20, legal_count)` racines distinctes au plus |
| T08 | position ayant >20 coups | au plus 20 racines, jamais étiquetées exhaustives |
| T09 | palier MultiPV | scores/pv/profondeurs/états corrects, pas de faux depth=21 |
| T10 | job annulation | processus stoppé, état cohérent, nouveau job possible |
| T11 | changement de position | anciennes lignes non affichées sur la nouvelle |
| T12 | crash/restart Stockfish | état job échoué/interrompu ; relance contrôlée |
| T13 | limites CPU/mémoire | aucun débordement infini ; ressources paramétrables |
| T14 | SQLite persistance | retrouver séance et ses nœuds après `docker compose down/up` |
| T15 | nouveau tag/image | installer utilise digest release attendu, pas `latest` |
| T16 | désinstallation | volume préservé par défaut |
| T17 | UI hors ligne | aucun CDN/fichier indispensable sur Internet après installation |
| T18 | écoute réseau | `127.0.0.1` uniquement côté Windows par défaut |

## Matrice pédagogique

| ID | Scénario | Critère de passage |
|---|---|---|
| P01 | Mode B avant révélation | aucun score/coup/PV visible **ni dans réponse API/SSE** |
| P02 | Mode C avant révélation | arbre utilisateur éditable, aucun conseil moteur transmis |
| P03 | Deux variantes à même parent | branches distinctes et navigation correcte |
| P04 | Variante alternative non évaluée | état `unverified` puis recherche à la demande |
| P05 | Coup illegal | refus serveur ; explication et arbre intact |
| P06 | Soumission | instantané immuable ; modification postérieure interdite |
| P07 | Classement moteur change pendant recherche | distinction provisoire/final, pas de correction trompeuse |
| P08 | Branche concurrente raisonnable | aucune pénalisation automatique sans preuve robuste |
| P09 | Mat, pat, répétition | bons états et conventions de scores explicites |
| P10 | Mode mental sans traces | autoévaluation seulement ; pas de score objectif inventé |
| P11 | Révélation | candidat et réfutation justifiables par coups légaux |
| P12 | Progression | historique distinct par séance et date |

## Corpus initial de 20 positions

Répartir : 4 combinaisons forcées, 3 défenses critiques, 3 positions calmes à candidats multiples, 3 finales, 2 promotions/EP/roques, 2 positions terminales, 3 pièges d'ambiguïté/évaluation instable. Garder une justification annotée humaine, sources des positions et licence si elles proviennent d'un répertoire externe. Éviter les positions tirées de parties avec droits incertains sans référence.

Tester aussi artificiellement un `Board` ayant moins de 20 coups légaux et une position à plus de 20 pour la logique de cardinalité ; ne pas inventer de FEN : générer/valider chaque fixture avec `python-chess` et stocker le verdict.

## Benchmarks moteurs reproductibles

Pour une machine de référence Linux/Windows (CPU modèle, RAM, WSL, Docker, date, température approximative si observée) mesurer :

- Temps et nœuds pour `MultiPV=1` profondeur 21.
- Temps et nœuds pour `MultiPV=min(20, legal_moves)` profondeur 8/12/16/21 ou budget atteint.
- Rendement `nodes/sec`, mémoire maximum, réactivité UI, latence d'annulation.
- Nombre de jobs et CPU idle ; bonne restitution d'état après crash.

**Pas de seuil de secondes universel.** Ajouter seuils relatifs sur machine CI après création d'un baseline, sans rendre la CI aléatoire à cause des différences de CPU runner.

## Sécurité tests

- Accès CORS cross-origin non autorisé ; Origin/Host inattendu rejeté.
- Test navigateur hostile avant `reveal` : n'obtient aucun détail moteur, même par endpoints auxiliaires.
- PGN commentaire `<script>` rendu en texte inerte.
- Entrées massives (PGN, arbres), débordement mémoire et jobs répétés refusés par des plafonds.
- API non exposée sur `0.0.0.0` de l'hôte Windows par défaut ; vérifier `docker compose ps` et port.

## Tests de bibliothèques UI

- `react-chessboard` version figée : éditeur avec spare pieces, promotion, orientation, désactivation du déplacement, clavier.
- `react-arborist` contrôlé : alternatives, repli, scroll long, clavier, pas de reparenting invalide.
- Parité `chess.js`/`python-chess` sur jeux de positions choisis ; serveur arbitre toute divergence.
- Playwright test de la position d'origine et tableau sous échiquier ; captures écrans desktop 1280px et laptop 1024px.

## Definition of Done d'une release

- CI verte, `docker compose config` réussi avec `.env` d'exemple et image réelle.
- Image publique tirable anonymement et `linux/amd64`.
- Release bundle SHA256 contrôlé.
- Test manuel Windows complet : install/start/stop/update/backup/uninstall (sans effacer données) et variante Docker non installé.
- README présente les limites de profondeur, la couverture sélective, le fonctionnement offline et la licence.
