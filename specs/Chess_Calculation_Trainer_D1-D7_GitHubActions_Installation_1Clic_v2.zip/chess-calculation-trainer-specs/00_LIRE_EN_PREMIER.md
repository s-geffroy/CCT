# Chess Calculation Trainer — dossier maître d'implémentation

**Statut :** spécification exécutable à implémenter (pas encore une application fonctionnelle).  
**Date de référence :** 26 octobre 2026.  
**Langue de l'interface :** français par défaut, architecture i18n prête pour l'anglais.  
**Nom provisoire :** *Chess Calculation Trainer* (nom de travail, aucune vérification de marque).  
**Distribution :** dépôt GitHub public, développement et CI sous Linux, exécution finale sous Windows 11 x64 via conteneurs Linux Docker Desktop/WSL 2.

## Parcours de lecture

| Ordre | Document | Objet |
|---|---|---|
| 1 | `01_CADRAGE_DECISIONS.md` | objectifs, D1–D7, périmètre et non-objectifs |
| 2 | `02_ARCHITECTURE.md` | responsabilités, processus, flux, invariants |
| 3 | `03_BIBLIOTHEQUES_UI.md` | comparaison des modules existants et choix ferme |
| 4 | `04_UX_ET_PARCOURS.md` | maquettes textuelles, modes A/B/C, parcours |
| 5 | `05_MODELE_DE_DONNEES.md` | schémas logiques, invariants, persistance |
| 6 | `06_MOTEUR_STOCKFISH.md` | recherche progressive, MultiPV, arbre adaptatif |
| 7 | `07_MOTEUR_PEDAGOGIQUE.md` | comparaison et diagnostics prudents |
| 8 | `08_API_ET_EVENEMENTS.md` | endpoints, flux SSE, exemples JSON |
| 9 | `09_DEVELOPPEMENT_LINUX_DOCKER.md` | développement, compilation, construction d'image |
| 10 | `10_PUBLICATION_GITHUB_WINDOWS.md` | GitHub Actions/GHCR/releases et installation Windows |
| 11 | `11_TESTS_ACCEPTATION.md` | tests automatisés, corpus, matrice qualité |
| 12 | `12_SECURITE_LICENCES.md` | hardening, redistribution, licences |
| 13 | `13_PLAN_IMPLEMENTATION.md` | lots de livraison et Definition of Done |
| 14 | `14_PROMPT_LLM_IMPLEMENTEUR.md` | **prompt complet à donner au LLM de développement** |
| 15 | `15_SOURCES_ET_VEILLE.md` | URLs officielles vérifiées et points à revérifier |
| 16 | `16_ANNEXE_SCRIPTS.md` | exemples de scripts Linux, PowerShell et packaging |
| 17 | `17_DECISIONS_DEFAUTS.md` | paramètres initiaux, arbitrages, risques |
| 18 | `18_ACTIVER_GITHUB_ACTIONS_ET_GHCR.md` | **activation de GitHub Actions, permissions, publications GHCR** |
| 19 | `19_INSTALLATION_WINDOWS_DOUBLE_CLIC.md` | **installation Windows par double-clic sur `INSTALLER.cmd`** |
| 20 | `20_TEMPLATES_CI_INSTALLATION_ET_CRITERES.md` | **modèles YAML/CMD/PowerShell et critères de release** |

## Consignes absolues au LLM d'implémentation

1. Lire **tout** ce dossier, commencer par `14_PROMPT_LLM_IMPLEMENTEUR.md` puis revenir aux spécifications citées.
2. Implémenter une **application qui marche**, tests et scripts inclus, et non uniquement des maquettes.
3. Faire les développements et tests sous **Linux** ; publier une **image Linux amd64** sur GHCR et une archive d'installation Windows en GitHub Release.
4. Fournir un chemin d'installation Windows **sans Python, Node ou Git sur la machine cible**. Docker Desktop/WSL 2 peuvent être des prérequis explicitement contrôlés.
5. Ne jamais confondre « 20 premières variantes », « arbre ramifié sélectionné » et « toutes les suites légales ». Aucune promesse d'exhaustivité.
6. Aucune fonctionnalité de conseil moteur visible pendant une séance de calcul mental avant la révélation autorisée.
7. Les interfaces sont faites à partir de bibliothèques maintenues : **ne pas réécrire un échiquier, un parseur PGN ou une bibliothèque de règles**.
8. Ne jamais publier l'image ou prétendre que les tests Windows sont passés si ce n'est pas le cas.

## Ajout de distribution : publication automatisée et double-clic Windows

Le dossier comprend désormais **21 fichiers Markdown** et des **modèles de fichiers techniques** sous `templates/` : workflow GitHub Actions, lanceurs `.cmd`, scripts PowerShell et Compose. L'implémenteur doit réellement coder l'application et intégrer/tester les modèles (voir documents 18 à 20). Après création d'une GitHub Release, le parcours utilisateur visé est : télécharger le ZIP Windows, **Extraire tout**, **double-cliquer `INSTALLER.cmd`**. Docker Desktop/WSL 2 demeurent des prérequis contrôlés et parfois à installer manuellement.

## Usage conseillé de ce ZIP

Décompresser le ZIP dans l'environnement Linux du développeur, puis fournir au LLM :

> « Implémente intégralement le produit spécifié dans ce dossier. Utilise `14_PROMPT_LLM_IMPLEMENTEUR.md` comme instruction principale, lis les autres Markdown comme contrat et produis le dépôt GitHub prêt pour une release Windows. »

## Définitions

- **Coup candidat** : coup initial possible de la position étudiée ; jusqu'à 20 coups retenus dans la présélection, sans prétendre couvrir tous les coups légaux.
- **PV** (*principal variation*) : ligne calculée par Stockfish à partir d'une position lors d'une recherche.
- **MultiPV 20** : jusqu'à 20 lignes dont les **premiers coups sont distincts**, et non un arbre complet.
- **Profondeur 21** : profondeur de recherche affichée par Stockfish, distincte de la longueur totale d'une ligne et de la profondeur de l'arbre de l'utilisateur.
- **Arbre utilisateur** : branches saisies par la personne en entraînement ; données originelles immuables pendant la correction.
- **Arbre de référence** : branches sélectionnées et évaluées, annotées avec provenance/limites de confiance.
- **Résultat provisoire** : évaluation destinée à être mise à jour ; ne sert pas à établir un diagnostic définitif.

## Limitations annoncées

Pas d'intégration initiale à Chess.com/Lichess, pas de synchronisation cloud, pas de comptes, pas de promesse de temps de calcul fixe, pas de garantie de couverture exhaustive, pas de Chess960 en V1, pas d'analyse d'images. Les utilisateurs doivent pouvoir exporter et sauvegarder leurs données localement.
