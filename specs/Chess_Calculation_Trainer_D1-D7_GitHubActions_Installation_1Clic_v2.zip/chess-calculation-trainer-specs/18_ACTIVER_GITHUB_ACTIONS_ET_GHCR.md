# 18 — Activer GitHub Actions, construire des conteneurs et publier sur GHCR

**Statut : procédure opérateur à appliquer au dépôt public après implémentation du logiciel.** Elle n'active rien dans un compte GitHub automatiquement. Vérifiée contre les documentations GitHub et Docker le 26 octobre 2026.

## Architecture des déclencheurs

| Événement | Fonction | Publie une image ? | Produit un installeur Windows ? |
|---|---|---|---|
| Pull request vers `main` | Valider code, tests, build de conteneur | Non | Non |
| Push sur `main` | Valider code, tests, build de conteneur | Non (politique V1) | Non |
| Actions > workflow > Run workflow | Lancer les mêmes vérifications à la demande | Non | Non |
| Push d'un tag `vX.Y.Z` | Construire image stable, push GHCR, GitHub Release | Oui | Oui |

Cette politique évite qu'un clic de test publie accidentellement une release. Pour publier, on crée volontairement un tag versionné après tests. Un déclenchement `workflow_dispatch` nécessite que le fichier de workflow soit sur la branche par défaut.

## 1. Préparer le dépôt

1. Créer un dépôt GitHub **Public**, par exemple `OWNER/chess-calculation-trainer` (remplacer `OWNER` partout par le vrai compte). Ne pas utiliser un dépôt fictif.
2. Pousser le code source du logiciel compilable et testé, **pas uniquement le présent ZIP de spécifications**.
3. Placer les workflows GitHub en `.github/workflows/` (pas dans `docs/`, pas dans `templates/`). Le modèle fourni est `templates/github/container-release.yml` à copier vers `.github/workflows/container-release.yml`.
4. Vérifier que `backend/Dockerfile` construit bien l'application complète avec le contexte racine `.` et que `make ci` lance de vrais tests.
5. Placer les fichiers de distribution Windows dans `packaging/windows/`, comme décrit par le document 19. Le modèle Compose doit être placé à la **racine du dépôt** en `compose.yaml`.
6. Pousser le commit sur `main` et vérifier l'apparition du workflow dans l'onglet Actions.

## 2. Autoriser GitHub Actions (interface GitHub)

1. Ouvrir le dépôt > **Settings** > **Actions** > **General**.
2. Dans **Actions permissions**, autoriser les actions nécessaires : option générale *Allow all actions and reusable workflows*, ou politique restrictive explicitement autorisant `actions/checkout` et les actions Docker référencées dans le workflow. Une politique d'organisation peut outrepasser celle du dépôt.
3. Dans **Workflow permissions**, conserver l'option globale **Read repository contents and packages permissions** si disponible. **Ne pas donner inutilement l'écriture globale à tous les workflows** : notre YAML donne les permissions spécifiques par job (`packages: write` pour publier l'image, `contents: write` pour créer la release).
4. Sauvegarder. Vérifier que GitHub Actions n'est pas désactivé au niveau de l'organisation ou du compte.
5. Onglet **Actions** > sélectionner « Container build and Windows release » > **Run workflow** > branche `main` > Run workflow. Cette exécution **vérifie** la construction mais ne publie pas de release.
6. Lire les journaux du workflow. Si les actions tierces sont bloquées, ajuster la liste d'autorisation plutôt que désactiver toute sécurité par défaut.

GitHub peut changer le libellé de l'interface : consulter <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository>.

## 3. Autorisations de publication et absence de PAT

Le workflow utilise uniquement le `GITHUB_TOKEN` temporaire fourni par GitHub Actions :

- job `build`: `contents: read`, `packages: write` ; `docker/login-action` avec `github.actor` et `secrets.GITHUB_TOKEN` ;
- job `release`: `contents: write` ; `gh release create` avec `GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}` ;
- **aucun personal access token (PAT) ni secret GHCR personnel** à créer dans le cas nominal ;
- tag créé sur une branche de confiance uniquement, branch protection + examen des PR recommandés ;
- permissions réduites et vérification des actions utilisées (pour une production durcie, épingler les actions aux SHA immuables contrôlés, et activer les mises à jour de dépendances).

En cas d'erreur `permission_denied: write_package`, inspecter d'abord les `permissions` du job, les éventuelles politiques d'organisation, le propriétaire/nom de package et « Manage Actions access » sur le package GitHub existant.

## 4. Préparer la toute première release

**Depuis un Linux de développement dont le dépôt et les tests sont à jour** :

```bash
git checkout main
git pull --ff-only
make ci
# Choisir une version réellement nouvelle et conforme aux versions Git du projet.
git tag -a v0.1.0 -m "Première release"
git push origin v0.1.0
```

Le **push du tag** déclenche la construction `linux/amd64`, la publication sur `ghcr.io/owner/repo:v0.1.0`, puis un ZIP Windows avec référence d'image **par digest** et son SHA256. Ne jamais forcer des tags versionnés déjà publiés ; publier une nouvelle version à la place.

Vérifier **Actions** > exécution `v0.1.0` > deux jobs verts, puis **Releases** > `v0.1.0` > archive Windows, `.sha256`, notes de version. La référence `ghcr.io/...@sha256:...` doit correspondre au digest renvoyé par Docker Build Push Action et figurer dans `release-manifest.json` de l'archive.

## 5. Rendre l'image GHCR publique (une opération manuelle importante)

**Un dépôt GitHub public ne rend pas automatiquement son image GHCR publique.** Le paquet peut être créé privé au premier push.

1. Sur le profil GitHub du propriétaire/organisation, ouvrir **Packages**.
2. Sélectionner le paquet du dépôt, puis **Package settings**.
3. Dans **Danger Zone** > **Change visibility**, choisir **Public** et confirmer après vérification du contenu. Cette opération peut être irréversible vers Private suivant la politique GitHub en vigueur : ne pas l'effectuer sans intention explicite.
4. Si package existant et erreur de droits : **Package settings** > **Manage Actions access** > **Add repository** et donner au dépôt l'accès requis pour publier. Le lien au dépôt source via label OCI est recommandé.
5. Tester le téléchargement **sans authentification** depuis une session Docker propre (ne pas retirer les identifiants personnels de la machine du développeur sans accord). Exemple sur runner/test isolé :

```bash
docker pull ghcr.io/owner/chess-calculation-trainer@sha256:REMPLACER_PAR_DIGEST_REEL
```

Le texte `REMPLACER_PAR_DIGEST_REEL` est intentionnellement non exécutable : substituer la valeur réelle du manifeste de release. **Ne pas indiquer « installation publique disponible » tant que ce test d'accès anonyme ne réussit pas.**

Référence : <https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility>.

## 6. Dépannage ciblé

| Symptôme | Cause probable | Résolution |
|---|---|---|
| Workflow absent | YAML non situé sous `.github/workflows/` ou non poussé sur branche par défaut | Vérifier chemin/commit et recharger Actions |
| « Workflow is disabled » | Actions coupées / politique organisation | Settings > Actions > General ; vérifier les restrictions héritées |
| Pas de bouton « Run workflow » | `workflow_dispatch` absent ou workflow non présent sur branche par défaut | Ajouter l'événement et merger sur `main` |
| `build-push-action` échoue | Dockerfile, dépendances, réseau NNUE ou compilation | Corriger le build Linux ; jamais sauter les tests |
| `denied: permission_denied: write_package` | GITHUB_TOKEN/accès package | Voir section 3 et « Manage Actions access » |
| Release non créée | `contents: write` absent ou fichier Windows manquant | Lire le journal du job `release`, corriger les permissions/fichiers |
| `docker pull` public refuse l'accès | GHCR encore privé | Changer la visibilité du **package**, pas seulement du dépôt |
| Archive sans `.cmd` ou manifest digest vide | Mauvais packaging | Bloquer release et réexécuter sur une nouvelle version corrigée |

## Critères d'acceptation spécifiques

- **G01** : Actions activées, Run workflow sur `main` vert, sans publication accidentelle.
- **G02** : PR non fiable ne dispose pas d'identifiants de publication et n'écrit ni package ni release.
- **G03** : tag `vX.Y.Z` produit une image amd64 taguée, digest immuable et archive Windows.
- **G04** : SHA256 publié calculé après création du ZIP ; archive identique à celle téléchargée.
- **G05** : package GHCR rendu public et `docker pull` anonyme réussi.
- **G06** : aucune image `:latest` utilisée comme référence d'installation.

## Sources officielles

- <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository>
- <https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow>
- <https://docs.github.com/en/actions/tutorials/publish-packages/publish-docker-images>
- <https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility>
- <https://docs.docker.com/build/ci/github-actions/>
