# 17 — Défauts, points ouverts non bloquants et registre de risques

## Défauts proposés (à mesurer, pas sacraliser)

| Paramètre | Défaut V1 | Raison |
|---|---|---|
| Langue | français, i18n prêt | utilisateur francophone, ouverture publique |
| Port Windows | `127.0.0.1:8765` | éviter collision 8000, local uniquement |
| Conteneurs production | un seul | sobriété pour utilisateur individuel |
| CPU conteneur | `2.0` CPU | réglable suivant PC |
| RAM conteneur | `2g` | réglable ; benchmark avec 8 Go host |
| Stockfish Threads | 2 ou moins si quota effectif <2 | préserver réactivité Windows |
| Stockfish Hash | 128 MiB | faible empreinte initiale |
| Profondeur moteur | 21 | demande explicite |
| Profondeurs paliers | 8,12,16,21 | retour progressif |
| MultiPV racine | jusqu'à 20 | demande explicite |
| Largeur de branches | 3 max auto | éviter explosion |
| Nœuds référence | 80 auto max | éviter explosion |
| Budgets recherche | 300s racine + 300s expansion par défaut | V1 conservative ; réglable |
| Jobs moteur actifs | 1 | sérialisation, aucune compétition CPU |
| Persistance | SQLite + volume nommé Docker | pas de base serveur externe |
| Cadence UI | état streaming SSE, re-render debounced | limiter surcharge |
| Thème | clair + contraste suffisant | utilisation pédagogique |
| Licence code original | GPL-3.0-or-later **proposée** | simplicité distribution avec Stockfish ; audit nécessaire |
| Architecture release | Linux amd64 | Windows 11 x64 Docker Desktop/WSL2 |

## Arbitrages explicitement non bloquants

- Ordre des onglets, choix du thème et icônes.
- Calibrage des seuils de criticité : **pas de verdict fort** tant que non validé ; privilégier diagnostic prudent.
- Paliers de profondeur : la recherche UCI rapportera des états, et l'utilisateur peut demander une approfondissement.
- Détail exact des étiquettes de réussite utilisateur, sans score global unique.
- Export PGN enrichi : priorité au respect des standards et à l'export JSON complet.
- Accélération CPU : pas d'AVX2 obligatoire pour des utilisateurs non équipés.

## Registre de risques

| Risque | Gravité | Mitigation / preuve |
|---|---|---|
| Demande « toutes les variantes » interprétée comme exhaustive | critique | interface dit « arbre sélectif », couverture explicite |
| Délais importants en MultiPV 20 depth 21 | élevé | budget, streaming, stop, cache, threads configurables |
| Fuite des meilleurs coups avant fin exercice | critique | API filtrée serveur + test E2E réseau |
| Rendu d'une ligne `score` hors contexte | élevé | un identifiant de job/position/révision sur chaque événement |
| Perte de l'historique PGN | élevé | pile UCI conservée ; statut histoire inconnue |
| Binaire AVX2 construit sur Linux non portable | critique | build générique et test CPU Windows cible |
| Release Windows dépendant d'outils développeurs | élevé | GHCR préconstruit, bundle script sans Python/Node/Git |
| Écrasement d'une base durant mise à jour | critique | sauvegarde SQLite cohérente avant migration, rollback documenté |
| Produit présenté comme scientifiquement validé | élevé | métriques modestes, jeux tests, protocoles ultérieurs |
| Stockfish NNUE manquants ou incompatibles | critique | vérification dans image finale au build et en healthcheck |
| Licences/PI et distribution | élevé | notices, sources correspondantes, audit avant release |

## Définition de `terminé` pour D7

Une recherche « terminée » peut signifier **budget épuisé** ou **profondeur atteinte**. L'interface ne doit pas employer une icône de succès générique pour les deux. Stocker explicitement l'état et le motif d'arrêt ; indiquer nombre de branches non explorées quand connu.
