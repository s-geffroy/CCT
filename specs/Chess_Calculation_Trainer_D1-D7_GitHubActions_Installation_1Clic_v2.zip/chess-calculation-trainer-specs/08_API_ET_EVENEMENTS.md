# 08 — Contrats HTTP REST et flux d'événements

## Principes

- Préfixe `/api/v1`, OpenAPI FastAPI généré et testé. DTO Pydantic stricts, ID UUID, dates ISO 8601 UTC.
- Toute mutation acceptée par backend seulement si position, branche et statut de séance le permettent.
- HTTP `409` : révision obsolète/conflit d'état ; `422` : coup/position non valide ; `404` : identifiant inconnu ; `429` : trop de travaux ; `503` : moteur indisponible.
- `revision` (entier monotone) dans arbres et sessions ; opérations conditionnelles par `expected_revision` pour éviter l'écrasement lors de double clic ou d'onglets concurrents.
- Les DTO d'exercice **pré-révélation** ne doivent pas inclure PV/scores/rangs ni références moteur, même sous clés cachées.
- Utiliser **SSE** (`text/event-stream`) pour les notifications **unidirectionnelles** de progression (plus simple que WebSocket) ; REST pour les commandes. L'architecture n'exige pas WebSocket.
- Entraînement et étude libre possèdent des vues d'API distinctes avec contrôles d'accès par état métier.

## Endpoints proposés

| Méthode | Chemin | Contrat |
|---|---|---|
| `GET` | `/api/v1/health/live` | processus opérationnel |
| `GET` | `/api/v1/health/ready` | base + moteur UCI initialisé |
| `GET` | `/api/v1/meta` | versions application/moteur et capacités |
| `POST` | `/api/v1/positions/validate` | valider FEN et expliquer les erreurs |
| `POST` | `/api/v1/positions` | créer snapshot position |
| `GET` | `/api/v1/positions/{id}` | snapshot normalisé et métadonnées |
| `POST` | `/api/v1/games/import-pgn` | import PGN borné, erreurs remontées |
| `GET` | `/api/v1/games/{id}/tree` | arbre importé paginé ou racine spécifiée |
| `POST` | `/api/v1/sessions` | créer exercice B ou C avec position figée |
| `GET` | `/api/v1/sessions/{id}` | données selon état et révélation |
| `POST` | `/api/v1/sessions/{id}/nodes` | ajouter coup légal dans arbre utilisateur |
| `PATCH` | `/api/v1/sessions/{id}/nodes/{node}` | commentaire/évaluation/ordre permis |
| `DELETE` | `/api/v1/sessions/{id}/nodes/{node}` | suppression de sous-arbre avant soumission |
| `POST` | `/api/v1/sessions/{id}/submit` | figer instantané utilisateur |
| `POST` | `/api/v1/sessions/{id}/reveal` | marquer révélée et ouvrir consultation de référence |
| `GET` | `/api/v1/sessions/{id}/review` | diagnostic, preuves et incertitudes |
| `POST` | `/api/v1/analysis-jobs` | créer travail, scope position/exercice, budget |
| `POST` | `/api/v1/analysis-jobs/{id}/cancel` | demander arrêt, idempotent |
| `GET` | `/api/v1/analysis-jobs/{id}` | état public ou complet autorisé |
| `GET` | `/api/v1/analysis-jobs/{id}/events` | SSE progression masquée ou complète |
| `GET` | `/api/v1/positions/{id}/reference-tree` | lecture complète seulement après révélation ou en étude libre |
| `POST` | `/api/v1/positions/{id}/expand` | réanalyse une branche/nœud |
| `GET` | `/api/v1/history` | sessions paginées |
| `GET`/`PUT` | `/api/v1/settings` | réglages bornés |
| `GET` | `/api/v1/sessions/{id}/export` | JSON/PGN encodé correctement |

## Exemples de DTO

### Validation FEN

```json
{
  "fen": "rb1qkb1r/pp3ppp/2n1pn2/2pp4/3P4/2NQPN2/PPP2PPP/R1B1K2R w KQkq - 0 1",
  "variant": "standard"
}
```

Réponse :

```json
{
  "valid": true,
  "normalized_fen": "rb1qkb1r/pp3ppp/2n1pn2/2pp4/3P4/2NQPN2/PPP2PPP/R1B1K2R w KQkq - 0 1",
  "turn": "white",
  "warnings": ["historique antérieur inconnu pour une FEN isolée"]
}
```

**Note :** cet exemple de réponse est partiel. Le contrat réel doit aussi inclure `legal_moves_count` comme entier calculé par `python-chess`. Son nombre exact pour cette FEN n’est volontairement pas inventé ici.

### Création de session

```json
{
  "position_id": "<uuid>",
  "mode": "mental",
  "allow_text_notes": true,
  "start_analysis_in_background": true
}
```

### Ajouter un nœud utilisateur

```json
{
  "parent_node_id": "<uuid-root-or-node>",
  "move_uci": "g1f3",
  "expected_revision": 12,
  "comment": "Je prévois ...Cf6"
}
```

Réponse : nœud créé, SAN **calculé côté serveur**, nouvelle révision, FEN résultante. Le serveur ne doit pas croire les SAN envoyés par le client.

### Job de recherche

```json
{
  "position_id": "<uuid>",
  "session_id": "<uuid-or-null>",
  "purpose": "initial_reference",
  "target_depth": 21,
  "multipv_max": 20,
  "total_budget_seconds": 300,
  "max_reference_nodes": 80
}
```

`POST` doit vérifier le droit de créer ce job (session/périmètre) et l'idempotence de la requête client. Il n'est pas permis d'obtenir les résultats cachés en analysant directement la même position via un endpoint sans contrôle quand un exercice non révélé est actif dans le navigateur. Variante simple V1 : mode étude libre séparé, politique de session explicite et aucun endpoint de recherche non gardé exposant des réponses sous le contexte secret d'une séance.

## SSE et anti-spoiler

Pendant l'exercice B/C non révélé :

```text
event: analysis-status
data: {"job_id":"...","state":"running","phase":"deepening","is_ready":false}
```

**Interdit avant révélation :** `pv_uci`, SAN d'une suggestion moteur, score, rang, meilleur coup, « nombre de coups corrects » ou métadonnées permettant de reconstruire les réponses. Pour masquer strictement le classement, l'événement peut se limiter à l'état global de job.

Après révélation ou en mode A :

```text
event: analysis-snapshot
id: 42
data: {"job_id":"...","position_id":"...","revision":42,"status":"provisional","depth":16,"lines":[{"root_move_uci":"e2e4","pv_uci":["e2e4","e7e5"],"score":{"kind":"cp","value":22,"perspective":"white"}}]}
```

Le flux doit gérer `Last-Event-ID` ou se reconnecter et réclamer l'état courant ; le serveur peut avoir un ring buffer borné, pas une histoire infinie de deltas. Inclure `heartbeat` toutes les 15–30 s pour détecter la déconnexion. SSE caché avant révélation **même si le job a terminé**.

## Erreurs sûres

```json
{"error":{"code":"ILLEGAL_MOVE","message":"Ce coup n'est pas légal depuis ce nœud.","details":{"parent_node_id":"..."}}}
```

Éviter les traces Python, FEN brutes dangereuses en logs, noms de fichiers locaux ou arguments internes d'exécutable dans les réponses publiques. Limiter taille FEN, PGN (ex. 5 MiB), nœuds importables, commentaires et débit de requêtes.

## Cohérence serveur-client

- À chaque navigation, garder `selected_position_id`/`selected_node_id` séparés de `training_root_position_id`.
- Ignorer les événements d'un `analysis_id` différent de l'analyse sélectionnée.
- Le journal SSE ne sert pas de base métier ; recharger `/analysis-jobs/{id}` après reconnexion.
- Les tests de sécurité doivent vérifier qu'un client HTTP/JS peut **vraiment** ne pas lire les réponses masquées avant révélation.
