# 03 — Recherche des bibliothèques UI : sélection et alternatives

**Vérification des informations publiques :** 26/10/2026. Le LLM revalide versions, API, compatibilités et licences avant de figer les lockfiles.

## Choix définitif pour la V1

| Besoin | Décision | Licence | Raison |
|---|---|---|---|
| Socle UI | React + TypeScript + Vite | voir dépendances | écosystème accessible et mature |
| Échiquier | **`react-chessboard`** (v5, adapter à l'API `options`) | MIT | glisser-déposer, orientation, styles, pièces libres pour éditeur, responsive |
| Arbre de variantes | **`react-arborist`** (v4 si validée) | MIT | nœuds contrôlés, arbres repliables, virtualisation, clavier |
| Éléments de formulaire/dialogues | **shadcn/ui** | MIT | contrôles prêts à l'emploi et personnalisables |
| Règles côté serveur | **`python-chess`** | GPL-3.0-or-later selon projet, vérifier métadonnées version | PGN multi-variantes, FEN, SAN, légalité, UCI |
| Règles UI rapides | `chess.js` (optionnel) | BSD-2-Clause | prévalidation et affordances ; jamais source de vérité |
| Recherche échiquéenne | **Stockfish 19 stable** | GPLv3-or-later | moteur UCI, NNUE ; figer tag/hash/net |
| Styles | CSS/Tailwind selon version shadcn choisie | voir dépendances | aucune feuille de style propriétaire externe |

## Pourquoi `react-chessboard` ?

Projet : <https://github.com/Clariity/react-chessboard>  
Documentation API : <https://react-chessboard.vercel.app/>  
Paquet : <https://www.npmjs.com/package/react-chessboard>

Fonctions attestées par le dépôt : déplacement des pièces, éléments libres (*spare pieces*), animation, gestion des événements, accessibilité, TypeScript, adaptation mobile. API actuelle basée sur :

```tsx
import { Chessboard } from 'react-chessboard';
const options = { /* choisir les options de la version épinglée */ };
return <Chessboard options={options} />;
```

**Obligation de validation :** écrire un *spike* de 1 jour au maximum testant glisser-déposer, édition pièces libres, promotion, orientation, surbrillance, déplacement désactivé et navigation clavier. Écrire l'adaptateur `ChessboardAdapter` isolant l'API externe. Ne pas coder en supposant une API `onPieceDrop` ancienne.

## Pourquoi `react-arborist` ?

Projet : <https://github.com/jameskerr/react-arborist>  
Paquet : <https://www.npmjs.com/package/react-arborist>

Fonctions : hiérarchie contrôlée, sélection, expansion, rendu custom, virtualisation et navigation clavier. Le paquet annonce des dépendances `react-dnd`/`react-dnd-html5-backend` : les installer/pinner au besoin et vérifier React/Node requis.

Pour un arbre échiquéen **désactiver la réorganisation par glisser-déposer** en V1 : il est incorrect de déplacer visuellement une suite de coups sous une position où elle n'est pas légale. Les seules opérations valides : ajout à un parent vérifié, suppression confirmée, promotion de branche principale, commentaire, repli/dépli, navigation.

Adapter interne :

```ts
type TreeRow = {
  id: string;
  parentId: string | null;
  moveUci: string | null;
  san: string;
  label: string;
  children: TreeRow[];
  origin: 'user' | 'reference' | 'imported';
  status: 'not_explored'|'provisional'|'reviewed'|'incomplete';
};
```

Le modèle stocké côté serveur reste indépendant de `TreeRow` ; la bibliothèque UI ne dicte pas la base de données.

## Alternatives examinées et non retenues

| Solution | Avantages | Décision |
|---|---|---|
| **Chessground** — <https://github.com/lichess-org/chessground> | très robuste, utilisé par Lichess, éditeur/analyse/affichage | alternative acceptable, GPL-3.0 ; intégration React moins directe, pas nécessaire pour V1 |
| **Lichess PGN Viewer** — <https://github.com/lichess-org/pgn-viewer> | visualisation PGN avec variantes | outil de lecture, pas un atelier d'entraînement complet ; licence GPL et personnalisation contraignante |
| **cm-chessboard** — <https://github.com/shaack/cm-chessboard> | échiquier flexible, MIT | alternative si spike `react-chessboard` échoue, intégration React à produire |
| **React Flow** — <https://reactflow.dev/> | graphe zoomable, MIT | bon pour *visualisation graphique optionnelle*, non pertinent comme vue principale d'un grand arbre de coups |
| Composant d'échiquier maison | contrôle total | refusé : coût élevé, bugs probables, aucune valeur pédagogique |
| Parseur PGN TypeScript maison | personnalisable | refusé : complexité, alternatives existantes (`python-chess`) |

## Comparaison ergonomique arbre vs graphe

La vue principale doit permettre : parcourir 21 demi-coups, distinguer variation principale/sous-variantes, comparer deux lignes et afficher des notes. Un arbre textuel type PGN est plus compact. Un diagramme géométrique se dégrade rapidement avec plusieurs dizaines de nœuds et impose zoom/pan. **Ne pas introduire React Flow tant qu'un test utilisateur ne montre pas un besoin clair.**

## Composants shadcn/ui demandés

`Button`, `Tabs`, `Dialog`, `AlertDialog`, `Tooltip`, `Accordion`, `Table`, `Select`, `Slider`, `Input`, `Textarea`, `Badge`, `Progress`, `Toast/Sonner` (selon version), `Separator`, `ScrollArea` ; rendre accessible au clavier. Pas de duplication de ces primitives.

## Spécificités échiquéennes à réaliser dans des adaptateurs fins

- Choix du camp au trait, droits au roque KQkq et champ de prise en passant.
- Mode édition avec palette de pièces et case vide.
- Saisie SAN textuelle et UCI en interne ; normaliser au backend.
- Import PGN contenant des RAV (*recursive annotation variations*) ; ne perdre ni commentaires ni variations.
- Mise en évidence du dernier coup, du coup sélectionné et éventuellement de la menace (uniquement après révélation).
- Confirmation des promotions ; pas de promotion silencieuse en dame dans les corrections.
- Mode mental : interactions de déplacement **désactivées**, mais orientation retournable si configurée.
- Mode C : construction de variantes autorisée sans montrer score ni candidats moteur.

## Dépendances & audit

Produire `package-lock.json` (ou `pnpm-lock.yaml` si pnpm retenu) et `uv.lock`/`requirements.lock` ; noter les licences dans `THIRD_PARTY_NOTICES.md`. Bloquer l'introduction de dépendances obsolètes sans alternative évaluée. Toute CDN tierce est proscrite : l'UI doit fonctionner hors ligne après installation.
